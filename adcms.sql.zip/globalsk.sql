-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 20, 2021 at 11:00 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.2.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `globalsk`
--

-- --------------------------------------------------------

--
-- Table structure for table `ad_agenda`
--

CREATE TABLE `ad_agenda` (
  `agenda_id` int(10) NOT NULL,
  `lang_id` int(10) NOT NULL DEFAULT '1',
  `name` varchar(100) NOT NULL,
  `dept` text NOT NULL,
  `category` varchar(180) NOT NULL,
  `description` text NOT NULL,
  `time_start` datetime NOT NULL,
  `time_finish` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `user_created` varchar(50) NOT NULL,
  `editor_approval` int(10) NOT NULL,
  `moderator_approval` int(10) NOT NULL,
  `is_published` int(10) NOT NULL,
  `date_published` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `user_modified` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_agenda`
--

INSERT INTO `ad_agenda` (`agenda_id`, `lang_id`, `name`, `dept`, `category`, `description`, `time_start`, `time_finish`, `date_created`, `user_created`, `editor_approval`, `moderator_approval`, `is_published`, `date_published`, `date_modified`, `user_modified`) VALUES
(1, 1, 'Temu KM 21 ( Penulis & Pebisnis Buku) dalam “Workshop Penulisan Buku”', 'http://www.unpad.ac.id/agenda/temu-km-21-penulis-pebisnis-buku-dalam-workshop-penulisan-buku/', '', '', '2016-04-06 07:18:00', NULL, '2016-07-01 00:00:00', 'aep darmawan', 1, 1, 1, '2016-07-28 04:05:22', NULL, NULL);
INSERT INTO `ad_agenda` (`agenda_id`, `lang_id`, `name`, `dept`, `category`, `description`, `time_start`, `time_finish`, `date_created`, `user_created`, `editor_approval`, `moderator_approval`, `is_published`, `date_published`, `date_modified`, `user_modified`) VALUES
(2, 1, 'Donor Darah Forum Komunikasi Mahasiswa Sekolah Pascasarjana Unpad', 'http://www.unpad.ac.id/agenda/donor-darah-forum-komunikasi-mahasiswa-sekolah-pascasarjana-unpad/', '', '', '2016-04-01 09:06:00', NULL, '1970-01-01 01:00:00', 'aep darmawan', 1, 1, 1, '1970-01-01 01:00:00', NULL, NULL);
INSERT INTO `ad_agenda` (`agenda_id`, `lang_id`, `name`, `dept`, `category`, `description`, `time_start`, `time_finish`, `date_created`, `user_created`, `editor_approval`, `moderator_approval`, `is_published`, `date_published`, `date_modified`, `user_modified`) VALUES
(3, 1, 'Kuliah Umum “Functional Food: Challenges and Opportunities from Industrial Perspective”', 'hhttp://www.unpad.ac.id/agenda/kuliah-umum-functional-food-challenges-and-opportunities-from-industrial-perspective/', '', '', '2016-04-01 09:07:00', NULL, '1970-01-01 01:00:00', 'aep darmawan', 1, 1, 1, '1970-01-01 01:00:00', NULL, NULL);
INSERT INTO `ad_agenda` (`agenda_id`, `lang_id`, `name`, `dept`, `category`, `description`, `time_start`, `time_finish`, `date_created`, `user_created`, `editor_approval`, `moderator_approval`, `is_published`, `date_published`, `date_modified`, `user_modified`) VALUES
(4, 1, 'Yamaha Online Video Workshop', 'http://www.unpad.ac.id/agenda/yamaha-online-video-workshop/', '', '', '2016-03-29 09:08:00', NULL, '1970-01-01 01:00:00', 'aep darmawan', 1, 1, 1, '1970-01-01 01:00:00', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ad_artikel`
--

CREATE TABLE `ad_artikel` (
  `article_id` int(6) NOT NULL,
  `lang_id` tinyint(2) NOT NULL DEFAULT '1',
  `article_title` varchar(250) NOT NULL,
  `summary` text,
  `content` longtext NOT NULL,
  `editor_approval` tinyint(1) NOT NULL DEFAULT '0',
  `moderator_approval` tinyint(1) NOT NULL DEFAULT '0',
  `is_published` tinyint(1) NOT NULL DEFAULT '0',
  `read_count` int(6) NOT NULL DEFAULT '0',
  `type_id` int(2) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `publish_date` datetime DEFAULT NULL,
  `tags` char(250) CHARACTER SET utf8 DEFAULT NULL,
  `page_title` char(250) CHARACTER SET utf8 DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `user_created` int(4) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `user_modified` int(4) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_artikel`
--

INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(1, 1, 'Daftar Lengkap Fitur Luar Biasa', '', '<h2 class=\"title\">Bangun Tim Penjualan Sukses Anda dengan Sintesis</h2>\n\n<p>Banyak fitur memungkinkan untuk menyesuaikan sistem sesuai dengan semua kebutuhan Anda.</p>\n', 1, 1, 1, 0, 4, NULL, '2016-07-20 00:00:00', '', '', '2016-07-20 00:00:00', 1, '2021-09-17 12:13:09', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(2, 1, 'Kehadiran', '', '<p><img alt=\"\" src=\"/sintesys/publik/rabmag/image/am-fea4.png\" style=\"width: 112px; height: 110px;\" /></p>\n', 1, 1, 1, 0, 4, NULL, '2018-04-16 00:00:00', '1', 'Kehadiran', '2018-07-17 00:00:00', 1, '2021-09-17 12:55:12', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(4, 2, 'In-Store Selling', '', '<p><img alt=\"\" src=\"/sintesys/publik/rabmag/image/productivity.png\" style=\"width: 108px; height: 125px;\" /></p>\n', 1, 1, 1, 0, 4, NULL, '2021-09-17 12:27:50', '3', '', '2016-07-20 00:00:00', 1, '2021-09-17 12:57:54', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(3, 1, 'Merchandising', '', '<p><img alt=\"\" src=\"/sintesys/publik/rabmag/image/colaboration.png\" style=\"width: 108px; height: 125px;\" /></p>\n', 1, 1, 1, 0, 4, NULL, '2021-09-17 00:00:00', '2', '', '2016-07-20 00:00:00', 1, '2021-09-17 17:39:30', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(4, 1, 'Penjualan di Toko', '', '<p><img alt=\"\" src=\"/sintesys/publik/rabmag/image/productivity.png\" style=\"width: 108px; height: 125px;\" /></p>\n', 1, 1, 1, 0, 4, NULL, '2021-09-17 00:00:00', '3', '', '2016-07-20 00:00:00', 1, '2021-09-17 12:57:41', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(2, 2, 'Attendance', '', '<p><img alt=\"\" src=\"/sintesys/publik/rabmag/image/am-fea4.png\" style=\"width: 112px; height: 110px;\" /></p>\n', 1, 1, 1, 0, 4, NULL, '2021-09-17 12:26:19', '1', 'Attendance', '2018-07-17 00:00:00', 1, '2021-09-17 12:56:13', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(5, 1, 'Rak', '', '<p><img alt=\"\" src=\"/sintesys/publik/rabmag/image/integrations.png\" style=\"width: 108px; height: 125px;\" /></p>\n', 1, 1, 1, 0, 4, NULL, '2021-09-17 00:00:00', '4', '', '2016-07-20 00:00:00', 1, '2021-09-17 12:58:10', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(5, 2, 'Shelving', '', '<p><img alt=\"\" src=\"/sintesys/publik/rabmag/image/integrations.png\" style=\"width: 108px; height: 125px;\" /></p>\n', 1, 1, 1, 0, 4, NULL, '2021-09-17 12:30:12', '4', '', '2016-07-20 00:00:00', 1, '2021-09-17 12:58:23', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(6, 1, 'Sales Intelligent System', '', '<p class=\"post-meta\">Real-time insights on retail execution and sales performance. Smarter merchandising, promotion, and sales execution tools for your field team.</p>\n\n<div class=\"banner-button-group\"><a class=\"button-4\" href=\"contact\">Schedule A Demo</a> <a class=\"button-4 active\" href=\"feature\">Explore Features</a></div>\n', 1, 1, 1, 0, 4, NULL, '2021-09-17 00:00:00', '', '', '2016-07-20 00:00:00', 1, '2021-09-17 21:10:23', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(7, 1, 'Temukan Wawasan Berharga Tentang Pasar Anda.', 'Antarmuka Pengguna Super Bersih | Jelajahi aplikasi generasi berikutnya. Aplikasi yang Anda butuhkan untuk memberi kekuatan  hidup Anda.', '<div class=\"counter--item\">\n<div class=\"counter-thumb\"><img alt=\"icon\" src=\"/sintesys/publik/rabmag/image/counter3.png\" /></div>\n\n<div class=\"counter-content\">\n<h2 class=\"title\"><span class=\"counter\">17501</span></h2>\n<span>Premium User</span></div>\n</div>\n\n<div class=\"counter--item\">\n<div class=\"counter-thumb\"><img alt=\"icon\" src=\"/sintesys/publik/rabmag/image/counter4.png\" /></div>\n\n<div class=\"counter-content\">\n<h2 class=\"title\"><span class=\"counter\">1,987</span></h2>\n<span>Daily Visitors</span></div>\n</div>\n\n<div class=\"counter--item\">\n<div class=\"counter-thumb\"><img alt=\"icon\" src=\"/sintesys/publik/rabmag/image/counter4.png\" /></div>\n\n<div class=\"counter-content\">\n<h2 class=\"title\"><span class=\"counter\">1,987</span></h2>\n<span>Daily Visitors</span></div>\n</div>\n\n<div class=\"counter--item\">\n<div class=\"counter-thumb\"><img alt=\"icon\" src=\"/sintesys/publik/rabmag/image/counter4.png\" /></div>\n\n<div class=\"counter-content\">\n<h2 class=\"title\"><span class=\"counter\">1,987</span></h2>\n<span>Daily Visitors</span></div>\n</div>\n', 1, 1, 1, 0, 4, NULL, '2016-07-20 00:00:00', '', 'Antarmuka Pengguna Super Bersih', '2016-07-20 00:00:00', 1, '2021-09-17 13:20:49', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(7, 2, 'Discover Valuable Insights About Your Market.', 'Super Clean User Interface | Explore app of the next generation.The only app you’ll need to power your life.', '<div class=\"counter--item\">\r\n<div class=\"counter-thumb\"><img alt=\"icon\" src=\"/sintesys/publik/rabmag/image/counter3.png\" /></div>\r\n\r\n<div class=\"counter-content\">\r\n<h2 class=\"title\"><span class=\"counter\">17501</span></h2>\r\n<span>Premium User</span></div>\r\n</div>\r\n\r\n<div class=\"counter--item\">\r\n<div class=\"counter-thumb\"><img alt=\"icon\" src=\"/sintesys/publik/rabmag/image/counter4.png\" /></div>\r\n\r\n<div class=\"counter-content\">\r\n<h2 class=\"title\"><span class=\"counter\">1,987</span></h2>\r\n<span>Daily Visitors</span></div>\r\n</div>\r\n\r\n<div class=\"counter--item\">\r\n<div class=\"counter-thumb\"><img alt=\"icon\" src=\"/sintesys/publik/rabmag/image/counter4.png\" /></div>\r\n\r\n<div class=\"counter-content\">\r\n<h2 class=\"title\"><span class=\"counter\">1,987</span></h2>\r\n<span>Daily Visitors</span></div>\r\n</div>\r\n\r\n<div class=\"counter--item\">\r\n<div class=\"counter-thumb\"><img alt=\"icon\" src=\"/sintesys/publik/rabmag/image/counter4.png\" /></div>\r\n\r\n<div class=\"counter-content\">\r\n<h2 class=\"title\"><span class=\"counter\">1,987</span></h2>\r\n<span>Daily Visitors</span></div>\r\n</div>\r\n', 1, 1, 1, 0, 4, NULL, '2021-09-17 13:05:29', '', 'Super Clean User Interface', '2016-07-20 00:00:00', 1, '2021-09-17 13:22:50', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(8, 1, 'Increase Sales', 'Sintesys advantages can', '<p>In the process of making a app, the satisfaction of users is the most important and the focus is on usability and completeness</p>\n', 1, 1, 1, 0, 4, NULL, '2017-04-11 00:00:00', '', 'Sintesys advantages', '2017-03-03 00:00:00', 1, '2021-09-17 13:38:58', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(9, 1, 'Increase Productivity & Performance', '', '<p>Forget about paper checklists, spreadsheets and time-consuming reports. Your salesperson can complete their work digitally. At HQ you get a real-time overview in your dashboard.</p>\n', 1, 1, 1, 0, 4, NULL, '2016-08-19 00:00:00', '1', '', '2016-08-19 00:00:00', 1, '2021-09-17 14:45:11', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(10, 1, 'Realtime Data', '', '<p>The satisfaction of users is the most important and the focus is on usability and completeness</p>\n', 1, 1, 1, 2, 4, NULL, '2018-04-19 00:00:00', '2', '', '2016-08-19 00:00:00', 1, '2021-09-17 14:45:53', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(11, 1, 'Easy to Manage Your All Data', '', '<p>The satisfaction of users is the most important and the focus is on usability and completeness</p>\n', 1, 1, 1, 0, 4, NULL, '2016-08-19 00:00:00', '3', '', '2016-08-19 00:00:00', 1, '2021-09-17 14:46:18', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(13, 1, 'Apps Without Borders', 'Our stats say more than any words | 4 | 312,921+', '<p>Sintesys app are growing by 300% every year with a steady love from users around the world. We are also close to achieving 10 million cumulative downloads.</p>\n', 1, 1, 1, 0, 4, NULL, '2016-08-19 00:00:00', '', 'Apps Without Borders', '2016-08-19 00:00:00', 1, '2021-09-17 16:33:41', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(12, 1, 'Offline Mode', '', '<p>Work anywhere with offline mode and keep your teams moving&mdash;even in areas of low connectivity.</p>\n', 1, 1, 1, 0, 4, NULL, '2016-08-19 00:00:00', '4', '', '2016-08-19 00:00:00', 1, '2021-09-17 14:46:43', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(14, 1, 'Coverage Map', '', '<div class=\"border-item-1\"><span class=\"name\">Sumatera</span>\n<h2 class=\"title\">70.7%</h2>\n</div>\n\n<div class=\"border-item-2\"><span class=\"name\">Papua</span>\n\n<h2 class=\"title\">14.4%</h2>\n</div>\n\n<div class=\"border-item-3\"><span class=\"name\">Sulawesi</span>\n\n<h2 class=\"title\">8.4%</h2>\n</div>\n\n<div class=\"border-item-4\"><span class=\"name\">Java</span>\n\n<h2 class=\"title\">1.8%</h2>\n</div>\n\n<div class=\"border-item-5\"><span class=\"name\">Borneo</span>\n\n<h2 class=\"title\">1.8%</h2>\n</div>\n\n<div class=\"border-item-6\"><span class=\"name\">Bali</span>\n\n<h2 class=\"title\">3%</h2>\n</div>\n', 1, 1, 1, 0, 4, NULL, '2016-08-19 00:00:00', '', 'Program Studi', '2016-08-18 00:00:00', 1, '2021-09-17 16:16:29', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(15, 1, 'Custom Plan', 'Gartner, \'Market Guide for Retail Workforce Management Applications\', Kelsie Marian, and Sam Grinter, July 26, 2021', '<h5 class=\"cate\">&ldquo;It is predicted that by 2023, up to 40% of Tier 1 retailers will leverage intelligent automation among their store workforce to improve business outcomes through better customer experience and associate engagement.&rdquo;</h5>\n', 1, 1, 1, 0, 4, NULL, '2016-08-19 00:00:00', '', '', '2016-08-19 00:00:00', 1, '2021-09-17 16:59:22', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(16, 1, 'How intelligent field teams win at retail', 'Sintesys Amazing Features', '<p>Numerous features make it possible to customize the system in accordance with all your needs.</p>\n', 1, 1, 1, 0, 10, NULL, '2016-08-19 00:00:00', '', '', '2016-08-19 00:00:00', 1, '2021-09-17 17:58:17', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(17, 1, 'Dashboard', '', '<p>Review team activity at a glance with summary-level metrics and trend reports on territory coverage and visits made.</p>\n', 1, 1, 1, 0, 10, NULL, '2016-08-19 00:00:00', 'Feature', '', '2016-08-19 00:00:00', 1, '2021-09-17 18:11:39', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(18, 1, 'Share all types of files and find them easily', 'Collaboration', '<ul>\n	<li>Drag and Drop files</li>\n	<li>Shared files</li>\n	<li>Share multiple file</li>\n</ul>\n', 1, 1, 1, 0, 10, NULL, '2021-09-15 00:00:00', 'Dashboard', '', '2016-08-18 00:00:00', 1, '2021-09-17 19:48:01', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(19, 1, 'Jump onto video calls with just a click', 'Collaboration', '<ul>\n	<li>Video Conferencing</li>\n	<li>Connect with remote teams</li>\n	<li>Share your screen</li>\n</ul>\n', 1, 1, 1, 0, 10, NULL, '2021-09-16 00:00:00', 'Dashboard', '', '2017-04-06 00:00:00', 1, '2021-09-17 19:48:27', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(24, 1, 'Share important news and updates with the entire team', 'Collaboration', '<ul>\n	<li>Announcement channels</li>\n	<li>Broadcast information</li>\n	<li>Sending email updates</li>\n</ul>\n', 1, 1, 1, 0, 10, NULL, '2021-09-18 00:00:00', 'Dashboard', '', '2018-04-05 00:00:00', 1, '2021-09-17 19:33:42', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(23, 1, 'Find whatever you\'re looking for', 'Collaboration', '<ul>\n	<li>fast and easy Search</li>\n	<li>Search files and links</li>\n	<li>Advanced search</li>\n</ul>\n', 1, 1, 1, 0, 10, NULL, '2021-09-17 00:00:00', 'Dashboard', '', '2016-08-18 00:00:00', 1, '2021-09-17 19:49:27', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(25, 1, 'Productivity', '', '<p>Boost your team&#39;s productivity and efficiency with our inbuilt tools. Collaborate with team members, share opinions, and manage your tasks more efficiently</p>\n', 1, 1, 1, 0, 10, NULL, '2018-04-20 00:00:00', 'Feature', '', '2018-04-12 00:00:00', 1, '2021-09-17 18:32:40', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(19, 2, 'Jump onto video calls with just a click', 'Collaboration', '<ul>\n	<li>Video Conferencing</li>\n	<li>Connect with remote teams</li>\n	<li>Share your screen</li>\n</ul>\n', 1, 1, 1, 0, 10, NULL, '2021-09-17 19:32:04', 'Dashboard', '', '2017-04-06 00:00:00', 1, '2021-09-17 19:29:16', NULL);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(26, 1, 'Convert discussions to tasks instantly', 'Productivity', '<ul>\n	<li>creating to-dos</li>\n	<li>Increase the conversion efficiency</li>\n	<li>Make checklists</li>\n</ul>\n', 1, 1, 1, 0, 10, NULL, '2021-09-15 00:00:00', 'Productivity', '', '2018-04-19 00:00:00', 1, '2021-09-17 19:53:47', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(27, 1, 'Create notes and collaborate with your team on the go', 'Productivity', '<ul>\n	<li>Notes feature</li>\n	<li>Share ideas quickly</li>\n	<li>Enhance team collaboration</li>\n</ul>\n', 1, 1, 1, 0, 10, NULL, '2021-09-18 00:00:00', 'Productivity', '', '2021-09-18 00:00:00', 1, '2021-09-17 19:58:25', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(28, 1, 'Integrations', '', '<p>Integrate your most frequently used third-party apps with Mosto. Choose from over 60+ apps listed on our Appstore or build your own.</p>\n', 1, 1, 1, 0, 10, NULL, '2021-09-15 00:00:00', 'Feature', '', '2021-09-15 00:00:00', 1, '2021-09-17 20:01:55', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(26, 2, 'Convert discussions to tasks instantly', '', '<p><strong>EDIT </strong>Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum, est ut placerat elementum, lectus nisl aliquam velit, tempor aliquam eros nunc nonummy metus. In eros metus, gravida a, gravida sed, lobortis id, turpis. Ut ultrices, ipsum at venenatis fringilla, sem nulla lacinia tellus, eget aliquet turpis mauris non enim. Nam turpis. Suspendisse lacinia. Curabitur ac tortor ut ipsum egestas elementum. Nunc imperdiet gravida mauris.</p>\n', 1, 1, 1, 0, 10, NULL, '2021-09-17 19:56:26', 'Productivity', '', '2018-04-19 00:00:00', 1, '2021-09-17 19:55:48', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(1, 2, 'An Exhaustive list of Amazing Features', '', '<h2 class=\"title\">Build Your Success Sales Team with Sintesys</h2>\n\n<p>Numerous features make it possible to customize the system in accordance with all your needs.</p>\n', 1, 1, 1, 0, 4, NULL, '2021-09-16 18:25:26', 'slogan glosika', '', '2016-07-20 00:00:00', 1, '2021-09-17 12:12:31', 1);
INSERT INTO `ad_artikel` (`article_id`, `lang_id`, `article_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(3, 2, 'Merchandising', '', '<p><img alt=\"\" src=\"/sintesys/publik/rabmag/image/colaboration.png\" style=\"width: 108px; height: 125px;\" /></p>\n', 1, 1, 1, 0, 4, NULL, '2021-09-16 18:48:16', '2', 'Merchandising', '2016-07-20 00:00:00', 1, '2021-09-17 12:57:25', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ad_berita`
--

CREATE TABLE `ad_berita` (
  `news_id` int(6) NOT NULL,
  `lang_id` tinyint(2) NOT NULL DEFAULT '1',
  `news_title` varchar(250) NOT NULL,
  `summary` text,
  `content` longtext NOT NULL,
  `editor_approval` tinyint(1) NOT NULL DEFAULT '0',
  `moderator_approval` tinyint(1) NOT NULL DEFAULT '0',
  `is_published` tinyint(1) NOT NULL DEFAULT '0',
  `read_count` int(10) NOT NULL DEFAULT '0',
  `type_id` int(2) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `publish_date` datetime DEFAULT NULL,
  `tags` char(250) CHARACTER SET utf8 DEFAULT NULL,
  `page_title` char(250) CHARACTER SET utf8 DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `user_created` int(4) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `user_modified` int(4) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_berita`
--

INSERT INTO `ad_berita` (`news_id`, `lang_id`, `news_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(1, 1, 'Mahasiswa Penerima BPPDN DIKTI', 'Mahasiswa Penerima BPPDN DIKTI Angkatan Tahun 2012 (S3), Tahun 2013 (S2 dan S3), Tahun 2014 (S2 dan S3)', '<p>Mahasiswa Penerima BPPDN DIKTI Angkatan Tahun 2012 (S3), Tahun 2013 (S2 dan S3), Tahun 2014 (S2 dan S3)</p>\r\n', 1, 1, 1, 0, 6, NULL, '2017-02-28 11:50:05', '', 'Mahasiswa Penerima BPPDN DIKTI', '2017-02-01 00:00:00', 1, NULL, NULL);
INSERT INTO `ad_berita` (`news_id`, `lang_id`, `news_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(2, 1, 'Beasiswa', 'Beasiswa Magister dan Doktor serta Beasiswa Tesis dan Disertasi dari Lembaga Pengelola Dana Pendidikan (LPDP)', '<p>Beasiswa Magister dan Doktor serta Beasiswa Tesis dan Disertasi dari Lembaga Pengelola Dana Pendidikan (LPDP)</p>\r\n', 1, 1, 1, 0, 6, NULL, '2017-02-28 11:56:45', '', 'Beasiswa', '2017-02-02 00:00:00', 1, NULL, NULL);
INSERT INTO `ad_berita` (`news_id`, `lang_id`, `news_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(3, 1, 'Implementasi Early Warning System ', '', '<p><span>Tgl Agst 19, 2016</span></p>\r\n\r\n<p>Informasi Herregistrasi bisa dibaca di http://unpad.ac.id/herregistrasi</p>\r\n', 1, 1, 1, 0, 6, NULL, '2017-02-28 11:56:49', '', 'Implementasi Early Warning System', '2017-02-03 00:00:00', 1, NULL, NULL);
INSERT INTO `ad_berita` (`news_id`, `lang_id`, `news_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(4, 1, 'Surat Edaran Dirjen Dikti', '', '<p class=\"post-meta\"><span class=\"date\">Tgl Mei 24, 2016</span></p>\r\n\r\n<div class=\"post-excerpt\">\r\n<p>Sehubungan dengan istilah literitas bidang ilmu yang berkaitan dengan pembukaan program studi, penerimaan dosen baru, dan kenaikan jenjang jabatan.</p>\r\n</div>\r\n', 1, 1, 1, 0, 6, NULL, '2017-02-28 12:53:55', '', 'Surat Edaran Dirjen Dikti', '2017-02-04 00:00:00', 1, NULL, NULL);
INSERT INTO `ad_berita` (`news_id`, `lang_id`, `news_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(5, 1, 'Perpanjangan Studi Program Doktor Angkatan Tahun 2013 Semester ke-8', '', '<p>Dalam rangka peningkatan layanan bagi dosen tetap pada perguruan tinggi di lingkungan Kementerian Riset Teknologi dan Pendidikan Tinggi, Direktorat Jenderal Sumber Daya Iptek dan Dikti menyediakan fasilitas bantuan perpanjangan Beasiswa Pendidikan Pascasarjana Dalam Negeri (BPPDN) bagi penerima BPPDN program Doktor (S3) angkatan tahun 2013 semester ke-8 (1 semester). Bagi dosen yang belum mendapatkan bantuan perpanjangan, kami mohon agar segera mengajukan, dengan persyarat sebagai berikut:</p>\r\n\r\n<ol>\r\n	<li>Masih aktif dan melakukan penelitian;</li>\r\n	<li>Telah lulus seminar ujian proposal penelitian disertasi;</li>\r\n	<li>Telah melakukan publikasi karya ilmiah dalam bentuk presiding seminar;</li>\r\n	<li>Mengunggah laporan kemajuan studi dari dokumen sebagaimana dimaksud pada diktum 1,2 dan 3 yang ditandatangani promotor dan kaprodi pada laman http://studi.ristekdikti.go.id mulai 1 - 7 Februari 2017</li>\r\n	<li>Penetapan status oleh pascasarjana pada laman http://studi.ristekdikti.go.id paling lambat 19 Februari 2017.</li>\r\n</ol>\r\n\r\n<p>Kami mohon agar dosen penerima BPP DN angkatan tahun 2013 segera menghubungi program/sekolah pascasarjana yang bersangkutan untuk mendapatkan username dan password yang akan digunakan untuk login ke dalam laman http://studi.ristekdikti.go.id</p>\r\n\r\n<p>Demikian kami sampaikan, atas perhatian dan kerjasama yang baik, kami ucapkan terima kasih.</p>\r\n', 1, 1, 1, 0, 6, NULL, '2017-03-01 00:00:00', '', '', '2017-02-05 00:00:00', 1, NULL, NULL);
INSERT INTO `ad_berita` (`news_id`, `lang_id`, `news_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(6, 1, 'Studi di Ilmu Liingkungan Unpad S2 dan S3 by Research dengan Beasiswa Unggulan', '', '<p><strong>Beasiswa Degree Dalam Negeri Jenjang S2</strong>:</p>\r\n\r\n<ol>\r\n	<li>Maksimal 32 Tahun</li>\r\n	<li>Memiliki LoA Unconditional</li>\r\n	<li>IPK S1, PTN 3.25 PTS 3.50</li>\r\n	<li>TOEFL ITP 500/IBT 61, IELTS 5.5</li>\r\n</ol>\r\n\r\n<p><strong>Beasiswa degree dalam Negeri jenjang S3:</strong></p>\r\n\r\n<ol>\r\n	<li>Maksimal 37 Tahun</li>\r\n	<li>Memiliki LoA Unconditional</li>\r\n	<li>IPK S2, PTN 3.25 PTS 3.50</li>\r\n	<li>TOEFL ITP 500/IBT 61, IELTS 5.5</li>\r\n</ol>\r\n\r\n<p><strong>Kelengkapan Berkas Beasiswa Degree:</strong></p>\r\n\r\n<ol>\r\n	<li>Kartu Tanda Penduduk (KTP)</li>\r\n	<li>LoA Unconditional</li>\r\n	<li>Ijazah dan Transkrip nilai terakhir</li>\r\n	<li>Sertifikat TOEFL/IELTS</li>\r\n	<li>Proposal rencana studi (rencana perkuliahan dan sksk per -semester yang akan ditempuh hingga selesai studi, topik apa yang akan ditulis dalam tesis/disertasi, deskripsi aktifitas di luar perkuliahan yang akan dilakukan selama studi dan bagaimana implementasi hasil studi di masyarakat)</li>\r\n	<li>Surat rekomendasii dari civitas akademik atau institusi terkait</li>\r\n	<li>Surat Pernyataan tidak sedang menerima beasiswa sejenis dari sumber lain</li>\r\n	<li>Sertifikat prestasi Nasional atau Internasional</li>\r\n	<li>Esai menggunakan Bahasa Indonesia dengan judul &quot;Aku Generasi Unggul Kebanggaan Bangsa Indonesia&quot; ditulis sebanyak 3-5 halaman pada kertas A4 dengan format huruf <em>Times New Roman</em> ukuran huruf 12 dengan spasi 1.5 liine&nbsp;</li>\r\n</ol>\r\n\r\n<p>Pendaftaran di Beasiswa unggulan : http://buonline.beasiswaunggulan.kemendikbud.go.id</p>\r\n\r\n<p><strong>Batch 1:</strong></p>\r\n\r\n<p>Pendaftaran: 15 Februari - 15 Agustus 2017</p>\r\n\r\n<p>Seleksi administrasi &amp; wawancara: 16 April - 10 Mei 2017</p>\r\n\r\n<p>Pengumuman: 12 Mei 2017</p>\r\n\r\n<p><strong>Batch 2:</strong></p>\r\n\r\n<p>Pendaftaran: 1 Juni-31 Juli 2017</p>\r\n\r\n<p>Seleksi administrasi &amp; wawancara: 1 Agustus -31 Agustus 2017</p>\r\n\r\n<p>Pengumuman: 1 September 2017</p>\r\n\r\n<p></p>\r\n\r\n<p><strong>Hubungi Ilmu Lingkungan Unpad:</strong></p>\r\n\r\n<ol>\r\n	<li>Sdri. Ely: 0823-1848-3599 (untuk S3)</li>\r\n	<li>Sdri. Tia: 0821-1666-0929 (untuk S2)</li>\r\n</ol>\r\n\r\n<p></p>\r\n\r\n<p></p>\r\n', 1, 1, 1, 0, 6, NULL, '2017-03-09 00:00:00', '', '', '2017-03-09 00:00:00', 1, '2017-03-09 07:24:45', 1);
INSERT INTO `ad_berita` (`news_id`, `lang_id`, `news_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(7, 1, 'Cek Bahasa', '', '<p><img alt=\"\" src=\"/pascasarjana/publik/images/news/5.jpg\" style=\"width: 214px; height: 167px; float: right;\" /></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas feugiat consequat diam. Maecenas metus. Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor. Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit. Nulla pretium mi et risus. Fusce mi pede, tempor id, cursus ac, ullamcorper nec, enim. Sed tortor. Curabitur molestie. Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum, est ut placerat elementum, lectus nisl aliquam velit, tempor aliquam eros nunc nonummy metus. In eros metus, gravida a, gravida sed, lobortis id, turpis. Ut ultrices, ipsum at venenatis fringilla, sem nulla lacinia tellus, eget aliquet turpis mauris non enim. Nam turpis. Suspendisse lacinia. Curabitur ac tortor ut ipsum egestas elementum. Nunc imperdiet gravida mauris.</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas feugiat consequat diam. Maecenas metus. Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor. Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit. Nulla pretium mi et risus. Fusce mi pede, tempor id, cursus ac, ullamcorper nec, enim. Sed tortor. Curabitur molestie. Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum, est ut placerat elementum, lectus nisl aliquam velit, tempor aliquam eros nunc nonummy metus. In eros metus, gravida a, gravida sed, lobortis id, turpis. Ut ultrices, ipsum at venenatis fringilla, sem nulla lacinia tellus, eget aliquet turpis mauris non enim. Nam turpis. Suspendisse lacinia. Curabitur ac tortor ut ipsum egestas elementum. Nunc imperdiet gravida mauris.</p>\r\n', 0, 0, 0, 0, 7, NULL, NULL, '', '', '2018-04-20 00:00:00', 1, '2018-04-19 21:52:35', 1);
INSERT INTO `ad_berita` (`news_id`, `lang_id`, `news_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(7, 2, 'Language Check', '', '<p><img alt=\"\" src=\"/pascasarjana/publik/images/news/5.jpg\" style=\"width: 214px; height: 167px; float: right;\" /></p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas feugiat consequat diam. Maecenas metus. Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor. Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit. Nulla pretium mi et risus. Fusce mi pede, tempor id, cursus ac, ullamcorper nec, enim. Sed tortor. Curabitur molestie. Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum, est ut placerat elementum, lectus nisl aliquam velit, tempor aliquam eros nunc nonummy metus. In eros metus, gravida a, gravida sed, lobortis id, turpis. Ut ultrices, ipsum at venenatis fringilla, sem nulla lacinia tellus, eget aliquet turpis mauris non enim. Nam turpis. Suspendisse lacinia. Curabitur ac tortor ut ipsum egestas elementum. Nunc imperdiet gravida mauris.</p>\r\n\r\n<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas feugiat consequat diam. Maecenas metus. Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor. Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit. Nulla pretium mi et risus. Fusce mi pede, tempor id, cursus ac, ullamcorper nec, enim. Sed tortor. Curabitur molestie. Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum, est ut placerat elementum, lectus nisl aliquam velit, tempor aliquam eros nunc nonummy metus. In eros metus, gravida a, gravida sed, lobortis id, turpis. Ut ultrices, ipsum at venenatis fringilla, sem nulla lacinia tellus, eget aliquet turpis mauris non enim. Nam turpis. Suspendisse lacinia. Curabitur ac tortor ut ipsum egestas elementum. Nunc imperdiet gravida mauris.</p>\r\n', 0, 0, 0, 0, 7, NULL, '2018-04-20 00:00:00', '', '', '2018-04-19 00:00:00', 1, '2018-04-19 21:57:18', 1);
INSERT INTO `ad_berita` (`news_id`, `lang_id`, `news_title`, `summary`, `content`, `editor_approval`, `moderator_approval`, `is_published`, `read_count`, `type_id`, `image`, `publish_date`, `tags`, `page_title`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(2, 2, 'EasyMoney', 'Beasiswa Magister dan Doktor serta Beasiswa Tesis dan Disertasi dari Lembaga Pengelola Dana Pendidikan (LPDP)', '<p>Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor. Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit. Nulla pretium mi et risus</p>\r\n\r\n<p>Beasiswa Magister dan Doktor serta Beasiswa Tesis dan Disertasi dari Lembaga Pengelola Dana Pendidikan (LPDP)</p>\r\n', 1, 1, 1, 0, 6, NULL, '2017-02-28 11:56:45', '', 'Beasiswa', '2017-02-02 00:00:00', 1, '2018-04-19 22:49:50', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ad_event`
--

CREATE TABLE `ad_event` (
  `event_id` int(10) NOT NULL,
  `lang_id` int(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `place` varchar(100) NOT NULL,
  `descriptionevent` longtext NOT NULL,
  `time_start` datetime NOT NULL,
  `time_finish` datetime NOT NULL,
  `date_created` datetime NOT NULL,
  `user_created` varchar(50) NOT NULL,
  `editor_approval` int(10) NOT NULL,
  `moderator_approval` int(10) NOT NULL,
  `is_published` int(10) NOT NULL,
  `date_published` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `user_modified` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ad_galeri`
--

CREATE TABLE `ad_galeri` (
  `galeri_id` int(6) NOT NULL,
  `article_id` int(6) DEFAULT NULL,
  `cat_id` int(4) DEFAULT NULL,
  `lang_id` tinyint(2) DEFAULT '1',
  `galeri_text` text,
  `description` text,
  `image` text,
  `urutan` int(2) NOT NULL DEFAULT '0',
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `editor_approval` tinyint(1) NOT NULL DEFAULT '0',
  `moderator_approval` tinyint(1) NOT NULL DEFAULT '0',
  `is_published` tinyint(1) DEFAULT '0',
  `published_date` datetime DEFAULT NULL,
  `user_created` int(4) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_modified` int(4) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_galeri`
--

INSERT INTO `ad_galeri` (`galeri_id`, `article_id`, `cat_id`, `lang_id`, `galeri_text`, `description`, `image`, `urutan`, `active`, `editor_approval`, `moderator_approval`, `is_published`, `published_date`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES
(1, NULL, 4, 1, 'Sponsor1', 'deskripsi', '1.png', 0, 1, 0, 0, 0, NULL, 0, '2018-04-19 19:20:10', 1, '2021-09-17 20:05:16');
INSERT INTO `ad_galeri` (`galeri_id`, `article_id`, `cat_id`, `lang_id`, `galeri_text`, `description`, `image`, `urutan`, `active`, `editor_approval`, `moderator_approval`, `is_published`, `published_date`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES
(2, NULL, 4, 1, 'Sponsor2', '', '2.png', 0, 1, 0, 0, 0, NULL, 0, '2018-04-19 19:19:46', 1, '2021-09-17 20:05:55');
INSERT INTO `ad_galeri` (`galeri_id`, `article_id`, `cat_id`, `lang_id`, `galeri_text`, `description`, `image`, `urutan`, `active`, `editor_approval`, `moderator_approval`, `is_published`, `published_date`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES
(3, NULL, 4, 1, 'Sponsor3', '', '3.png', 0, 1, 0, 0, 0, NULL, 0, '2018-04-19 19:20:44', 1, '2021-09-17 20:06:27');
INSERT INTO `ad_galeri` (`galeri_id`, `article_id`, `cat_id`, `lang_id`, `galeri_text`, `description`, `image`, `urutan`, `active`, `editor_approval`, `moderator_approval`, `is_published`, `published_date`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES
(4, NULL, 4, 1, 'Sponsor4', '', '4.png', 0, 1, 0, 0, 0, NULL, 0, '2018-04-19 19:36:03', 1, '2021-09-17 20:06:48');
INSERT INTO `ad_galeri` (`galeri_id`, `article_id`, `cat_id`, `lang_id`, `galeri_text`, `description`, `image`, `urutan`, `active`, `editor_approval`, `moderator_approval`, `is_published`, `published_date`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES
(5, NULL, 4, 1, 'Sponsor5', '', '5.png', 0, 1, 0, 0, 0, NULL, 0, '2018-04-19 19:51:12', 1, '2021-09-17 20:07:07');
INSERT INTO `ad_galeri` (`galeri_id`, `article_id`, `cat_id`, `lang_id`, `galeri_text`, `description`, `image`, `urutan`, `active`, `editor_approval`, `moderator_approval`, `is_published`, `published_date`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES
(6, NULL, 4, 1, 'Sponsor6', '', '6.png', 0, 1, 0, 0, 0, NULL, 0, '2018-04-19 19:54:56', 1, '2021-09-17 20:07:27');
INSERT INTO `ad_galeri` (`galeri_id`, `article_id`, `cat_id`, `lang_id`, `galeri_text`, `description`, `image`, `urutan`, `active`, `editor_approval`, `moderator_approval`, `is_published`, `published_date`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES
(7, NULL, 4, 1, 'Sponsor7', '', '7.png', 0, 1, 0, 0, 0, NULL, 1, '2018-04-24 00:00:00', 1, '2021-09-17 20:08:08');
INSERT INTO `ad_galeri` (`galeri_id`, `article_id`, `cat_id`, `lang_id`, `galeri_text`, `description`, `image`, `urutan`, `active`, `editor_approval`, `moderator_approval`, `is_published`, `published_date`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES
(8, NULL, 4, 1, 'Sponsor8', '', 'sponsor1.png', 0, 1, 0, 0, 0, NULL, 1, '2018-04-24 10:25:27', 1, '2021-09-17 20:08:43');

-- --------------------------------------------------------

--
-- Table structure for table `ad_image`
--

CREATE TABLE `ad_image` (
  `image_id` int(11) NOT NULL,
  `image_name` text,
  `image_path` text,
  `date_inserted` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cat_id` int(10) DEFAULT NULL,
  `mainimg` int(10) NOT NULL DEFAULT '0',
  `refftype` char(15) DEFAULT NULL,
  `reffid` int(10) DEFAULT NULL,
  `type_id` smallint(1) DEFAULT NULL,
  `active` tinyint(3) NOT NULL DEFAULT '0',
  `user_created` int(4) NOT NULL,
  `user_modified` int(4) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_image`
--

INSERT INTO `ad_image` (`image_id`, `image_name`, `image_path`, `date_inserted`, `cat_id`, `mainimg`, `refftype`, `reffid`, `type_id`, `active`, `user_created`, `user_modified`, `date_modified`) VALUES
(7, 'ikon Pro main 2', 'pro1.png', '2018-04-20 04:57:24', NULL, 0, 'artikel', 9, NULL, 1, 1, 1, '2021-09-17 14:49:13');
INSERT INTO `ad_image` (`image_id`, `image_name`, `image_path`, `date_inserted`, `cat_id`, `mainimg`, `refftype`, `reffid`, `type_id`, `active`, `user_created`, `user_modified`, `date_modified`) VALUES
(5, 'Pro Main 2', 'pro-main2.png', '2018-04-20 05:00:12', NULL, 1, 'artikel', 9, NULL, 1, 1, 1, '2021-09-17 14:04:56');
INSERT INTO `ad_image` (`image_id`, `image_name`, `image_path`, `date_inserted`, `cat_id`, `mainimg`, `refftype`, `reffid`, `type_id`, `active`, `user_created`, `user_modified`, `date_modified`) VALUES
(8, 'Pro main', 'pro-main.png', '2018-04-20 05:00:57', NULL, 1, 'artikel', 10, NULL, 1, 1, 1, '2021-09-17 14:06:43');
INSERT INTO `ad_image` (`image_id`, `image_name`, `image_path`, `date_inserted`, `cat_id`, `mainimg`, `refftype`, `reffid`, `type_id`, `active`, `user_created`, `user_modified`, `date_modified`) VALUES
(10, 'Ikon Pro main', 'pro2.png', '2018-04-20 04:56:07', NULL, 0, 'artikel', 10, NULL, 1, 1, 1, '2021-09-17 14:07:18');
INSERT INTO `ad_image` (`image_id`, `image_name`, `image_path`, `date_inserted`, `cat_id`, `mainimg`, `refftype`, `reffid`, `type_id`, `active`, `user_created`, `user_modified`, `date_modified`) VALUES
(15, 'Pro Main 3', 'pro-main3.png', '2018-04-24 10:28:11', NULL, 1, 'artikel', 11, NULL, 1, 1, 1, '2021-09-17 14:08:03');
INSERT INTO `ad_image` (`image_id`, `image_name`, `image_path`, `date_inserted`, `cat_id`, `mainimg`, `refftype`, `reffid`, `type_id`, `active`, `user_created`, `user_modified`, `date_modified`) VALUES
(16, 'Ikon Pro Main 3', 'pro3.png', '2021-09-17 19:08:47', NULL, 0, 'artikel', 11, NULL, 1, 1, NULL, NULL);
INSERT INTO `ad_image` (`image_id`, `image_name`, `image_path`, `date_inserted`, `cat_id`, `mainimg`, `refftype`, `reffid`, `type_id`, `active`, `user_created`, `user_modified`, `date_modified`) VALUES
(17, 'Pro Main 4', 'pro-main4.png', '2021-09-17 19:09:22', NULL, 1, 'artikel', 12, NULL, 1, 1, 1, '2021-09-17 14:12:04');
INSERT INTO `ad_image` (`image_id`, `image_name`, `image_path`, `date_inserted`, `cat_id`, `mainimg`, `refftype`, `reffid`, `type_id`, `active`, `user_created`, `user_modified`, `date_modified`) VALUES
(18, 'Ikon Pro Main 4', 'pro4.png', '2021-09-17 19:09:58', NULL, 0, 'artikel', 12, NULL, 1, 1, 1, '2021-09-17 14:12:16');
INSERT INTO `ad_image` (`image_id`, `image_name`, `image_path`, `date_inserted`, `cat_id`, `mainimg`, `refftype`, `reffid`, `type_id`, `active`, `user_created`, `user_modified`, `date_modified`) VALUES
(19, 'Share all types of files and find them easily', 'feat1.png', '2021-09-18 00:06:04', NULL, 1, 'artikel', 18, NULL, 1, 1, NULL, NULL);
INSERT INTO `ad_image` (`image_id`, `image_name`, `image_path`, `date_inserted`, `cat_id`, `mainimg`, `refftype`, `reffid`, `type_id`, `active`, `user_created`, `user_modified`, `date_modified`) VALUES
(20, 'Ikon Share all types of files and find them easily', 'colaboration.png', '2021-09-18 00:06:59', NULL, 0, 'artikel', 18, NULL, 1, 1, NULL, NULL);
INSERT INTO `ad_image` (`image_id`, `image_name`, `image_path`, `date_inserted`, `cat_id`, `mainimg`, `refftype`, `reffid`, `type_id`, `active`, `user_created`, `user_modified`, `date_modified`) VALUES
(21, 'Find whatever you\'re looking for', 'feat4.png', '2021-09-18 00:25:03', NULL, 1, 'artikel', 23, NULL, 1, 1, NULL, NULL);
INSERT INTO `ad_image` (`image_id`, `image_name`, `image_path`, `date_inserted`, `cat_id`, `mainimg`, `refftype`, `reffid`, `type_id`, `active`, `user_created`, `user_modified`, `date_modified`) VALUES
(22, 'Jump onto video calls with just a click', 'feat2.png', '2021-09-18 00:45:30', NULL, 1, 'artikel', 19, NULL, 1, 1, NULL, NULL);
INSERT INTO `ad_image` (`image_id`, `image_name`, `image_path`, `date_inserted`, `cat_id`, `mainimg`, `refftype`, `reffid`, `type_id`, `active`, `user_created`, `user_modified`, `date_modified`) VALUES
(23, 'Convert discussions to tasks instantly', 'feat6.png', '2021-09-18 00:52:50', NULL, 1, 'artikel', 26, NULL, 1, 1, NULL, NULL);
INSERT INTO `ad_image` (`image_id`, `image_name`, `image_path`, `date_inserted`, `cat_id`, `mainimg`, `refftype`, `reffid`, `type_id`, `active`, `user_created`, `user_modified`, `date_modified`) VALUES
(24, 'Create notes and collaborate with your team on the go', 'feat7.png', '2021-09-18 00:59:20', NULL, 1, 'artikel', 27, NULL, 1, 1, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ad_kategori_agenda`
--

CREATE TABLE `ad_kategori_agenda` (
  `category_id` int(10) NOT NULL,
  `category` varchar(100) NOT NULL,
  `ordered` smallint(2) NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `user_created` varchar(50) NOT NULL,
  `editor_approval` int(10) NOT NULL,
  `moderator_approval` int(10) NOT NULL,
  `is_published` int(10) NOT NULL,
  `date_published` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `user_modified` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ad_kategori_artikel`
--

CREATE TABLE `ad_kategori_artikel` (
  `cat_id` int(4) NOT NULL,
  `name` varchar(50) NOT NULL,
  `article_id` int(6) NOT NULL,
  `lang_id` tinyint(2) NOT NULL DEFAULT '1',
  `urutan` int(2) NOT NULL DEFAULT '0',
  `tbl_id` int(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_kategori_artikel`
--

INSERT INTO `ad_kategori_artikel` (`cat_id`, `name`, `article_id`, `lang_id`, `urutan`, `tbl_id`) VALUES
(1, 'Section Amazing Feature', 1, 1, 0, 1);
INSERT INTO `ad_kategori_artikel` (`cat_id`, `name`, `article_id`, `lang_id`, `urutan`, `tbl_id`) VALUES
(8, 'Section Feature Sub', 10, 1, 2, 61);
INSERT INTO `ad_kategori_artikel` (`cat_id`, `name`, `article_id`, `lang_id`, `urutan`, `tbl_id`) VALUES
(4, 'Section Amazing Feature Sub', 4, 1, 0, 56);
INSERT INTO `ad_kategori_artikel` (`cat_id`, `name`, `article_id`, `lang_id`, `urutan`, `tbl_id`) VALUES
(8, 'Section Feature Sub', 11, 1, 3, 62);
INSERT INTO `ad_kategori_artikel` (`cat_id`, `name`, `article_id`, `lang_id`, `urutan`, `tbl_id`) VALUES
(5, 'Section Counter', 7, 1, 4, 58);
INSERT INTO `ad_kategori_artikel` (`cat_id`, `name`, `article_id`, `lang_id`, `urutan`, `tbl_id`) VALUES
(8, 'Section Feature Sub', 9, 1, 0, 60);
INSERT INTO `ad_kategori_artikel` (`cat_id`, `name`, `article_id`, `lang_id`, `urutan`, `tbl_id`) VALUES
(10, 'Section Coverage', 13, 1, 0, 64);
INSERT INTO `ad_kategori_artikel` (`cat_id`, `name`, `article_id`, `lang_id`, `urutan`, `tbl_id`) VALUES
(9, 'Banner', 6, 1, 0, 53);
INSERT INTO `ad_kategori_artikel` (`cat_id`, `name`, `article_id`, `lang_id`, `urutan`, `tbl_id`) VALUES
(4, 'Section Amazing Feature Sub', 3, 1, 0, 55);
INSERT INTO `ad_kategori_artikel` (`cat_id`, `name`, `article_id`, `lang_id`, `urutan`, `tbl_id`) VALUES
(4, 'Section Amazing Feature Sub', 2, 1, 0, 54);
INSERT INTO `ad_kategori_artikel` (`cat_id`, `name`, `article_id`, `lang_id`, `urutan`, `tbl_id`) VALUES
(4, 'Section Amazing Feature Sub', 5, 1, 0, 57);
INSERT INTO `ad_kategori_artikel` (`cat_id`, `name`, `article_id`, `lang_id`, `urutan`, `tbl_id`) VALUES
(7, 'Section Feature', 8, 1, 0, 59);
INSERT INTO `ad_kategori_artikel` (`cat_id`, `name`, `article_id`, `lang_id`, `urutan`, `tbl_id`) VALUES
(8, 'Section Feature Sub', 12, 1, 4, 63);
INSERT INTO `ad_kategori_artikel` (`cat_id`, `name`, `article_id`, `lang_id`, `urutan`, `tbl_id`) VALUES
(10, 'Section Coverage', 14, 1, 0, 65);
INSERT INTO `ad_kategori_artikel` (`cat_id`, `name`, `article_id`, `lang_id`, `urutan`, `tbl_id`) VALUES
(11, 'Section Custom-Plan', 15, 1, 0, 66);

-- --------------------------------------------------------

--
-- Table structure for table `ad_kategori_berita`
--

CREATE TABLE `ad_kategori_berita` (
  `cat_id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `news_id` int(10) NOT NULL,
  `lang_id` char(10) CHARACTER SET utf8 NOT NULL DEFAULT '1',
  `urutan` int(2) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_kategori_berita`
--

INSERT INTO `ad_kategori_berita` (`cat_id`, `name`, `news_id`, `lang_id`, `urutan`) VALUES
(1, 'ngetes', 2, '1', 0);
INSERT INTO `ad_kategori_berita` (`cat_id`, `name`, `news_id`, `lang_id`, `urutan`) VALUES
(1, 'ngetes', 4, '1', 0);

-- --------------------------------------------------------

--
-- Table structure for table `ad_kategori_galeri`
--

CREATE TABLE `ad_kategori_galeri` (
  `cat_id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_kategori_galeri`
--

INSERT INTO `ad_kategori_galeri` (`cat_id`, `name`) VALUES
(1, 'Banner'),
(2, 'Album'),
(3, 'Partner');
INSERT INTO `ad_kategori_galeri` (`cat_id`, `name`) VALUES
(4, 'Sponsor');

-- --------------------------------------------------------

--
-- Table structure for table `ad_kategori_product`
--

CREATE TABLE `ad_kategori_product` (
  `cat_id` int(4) NOT NULL,
  `name` varchar(180) NOT NULL,
  `type_id` int(2) NOT NULL,
  `lang_id` tinyint(2) NOT NULL DEFAULT '1',
  `urutan` int(2) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_kategori_product`
--

INSERT INTO `ad_kategori_product` (`cat_id`, `name`, `type_id`, `lang_id`, `urutan`) VALUES
(1, 'System Integrator', 15, 1, 1);
INSERT INTO `ad_kategori_product` (`cat_id`, `name`, `type_id`, `lang_id`, `urutan`) VALUES
(2, 'IT Service Management', 16, 1, 2);
INSERT INTO `ad_kategori_product` (`cat_id`, `name`, `type_id`, `lang_id`, `urutan`) VALUES
(3, 'Digital Marketing\r\n', 16, 1, 3);
INSERT INTO `ad_kategori_product` (`cat_id`, `name`, `type_id`, `lang_id`, `urutan`) VALUES
(4, 'Supply Chain Management', 16, 1, 4);
INSERT INTO `ad_kategori_product` (`cat_id`, `name`, `type_id`, `lang_id`, `urutan`) VALUES
(5, 'Brand Activations', 16, 1, 1);
INSERT INTO `ad_kategori_product` (`cat_id`, `name`, `type_id`, `lang_id`, `urutan`) VALUES
(6, 'Brand Strategy', 16, 1, 2);
INSERT INTO `ad_kategori_product` (`cat_id`, `name`, `type_id`, `lang_id`, `urutan`) VALUES
(7, 'Brand  Digital Activation', 16, 1, 3);
INSERT INTO `ad_kategori_product` (`cat_id`, `name`, `type_id`, `lang_id`, `urutan`) VALUES
(8, 'MICE', 16, 1, 4);
INSERT INTO `ad_kategori_product` (`cat_id`, `name`, `type_id`, `lang_id`, `urutan`) VALUES
(9, 'Services', 16, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `ad_kategori_project`
--

CREATE TABLE `ad_kategori_project` (
  `cat_id` int(4) NOT NULL,
  `name` varchar(50) NOT NULL,
  `article_id` int(6) NOT NULL,
  `lang_id` tinyint(2) NOT NULL DEFAULT '1',
  `urutan` int(2) NOT NULL DEFAULT '0',
  `tbl_id` int(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ad_komentar`
--

CREATE TABLE `ad_komentar` (
  `id` int(11) NOT NULL,
  `name` varchar(125) NOT NULL,
  `email` varchar(125) NOT NULL,
  `comment` text NOT NULL,
  `ip` varchar(200) NOT NULL,
  `date_created` datetime NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ad_konfigurasi`
--

CREATE TABLE `ad_konfigurasi` (
  `kode` int(2) NOT NULL,
  `nama` char(175) NOT NULL,
  `keterangan` text,
  `kunci` char(15) NOT NULL,
  `nilai` text NOT NULL,
  `urutan` tinyint(2) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_konfigurasi`
--

INSERT INTO `ad_konfigurasi` (`kode`, `nama`, `keterangan`, `kunci`, `nilai`, `urutan`) VALUES
(1, 'Nama Site', 'Isi dengan nama website', 'NM_SITE', 'Website Sintesys', 1);
INSERT INTO `ad_konfigurasi` (`kode`, `nama`, `keterangan`, `kunci`, `nilai`, `urutan`) VALUES
(2, 'Nama Perusahaan', 'Isi dengan nama perusahaan', 'NM_COMPANY', 'Sintesys', 2);
INSERT INTO `ad_konfigurasi` (`kode`, `nama`, `keterangan`, `kunci`, `nilai`, `urutan`) VALUES
(4, 'Alamat', 'Isi dengan informasi alamat', 'NM_ALAMAT', 'Jl. RS. Fatmawati 110, Gandaria Selatan, Cilandak, Jakarta Selatan 12420, Indonesia', 3);
INSERT INTO `ad_konfigurasi` (`kode`, `nama`, `keterangan`, `kunci`, `nilai`, `urutan`) VALUES
(5, 'Email', 'Isi dengan email', 'NM_EMAIL', 'info@sintesys.id', 5);
INSERT INTO `ad_konfigurasi` (`kode`, `nama`, `keterangan`, `kunci`, `nilai`, `urutan`) VALUES
(6, 'Nomor Telepon', 'Isi dengan nomor telepon', 'NM_TLP', '+62-21-7243109', 6);
INSERT INTO `ad_konfigurasi` (`kode`, `nama`, `keterangan`, `kunci`, `nilai`, `urutan`) VALUES
(7, 'Nomor HP', 'Isi dengan nomor HP', 'NM_HP', '', 7);
INSERT INTO `ad_konfigurasi` (`kode`, `nama`, `keterangan`, `kunci`, `nilai`, `urutan`) VALUES
(8, 'Lokasi Peta', 'Isi dengan koordinat long lang', 'NM_LOKASI', '', 4);
INSERT INTO `ad_konfigurasi` (`kode`, `nama`, `keterangan`, `kunci`, `nilai`, `urutan`) VALUES
(9, 'Facebook', 'Facebook', 'NM_FACEBOOK', '', 8);
INSERT INTO `ad_konfigurasi` (`kode`, `nama`, `keterangan`, `kunci`, `nilai`, `urutan`) VALUES
(10, 'WA', 'Whatapp', 'NM_WA', '', 10);
INSERT INTO `ad_konfigurasi` (`kode`, `nama`, `keterangan`, `kunci`, `nilai`, `urutan`) VALUES
(11, 'Twitter', 'Twitter', 'NM_TWITTER', '', 9);
INSERT INTO `ad_konfigurasi` (`kode`, `nama`, `keterangan`, `kunci`, `nilai`, `urutan`) VALUES
(12, 'Instagram', 'Instagram', 'NM_INSTAGRAM', '', 11);
INSERT INTO `ad_konfigurasi` (`kode`, `nama`, `keterangan`, `kunci`, `nilai`, `urutan`) VALUES
(13, 'pinterest', 'pinterest', 'NM_PINTEREST', '', 12);
INSERT INTO `ad_konfigurasi` (`kode`, `nama`, `keterangan`, `kunci`, `nilai`, `urutan`) VALUES
(14, 'Kode Aktifasi', 'Kode Aktifasi', 'NM_AKTIFASI', '', 13);
INSERT INTO `ad_konfigurasi` (`kode`, `nama`, `keterangan`, `kunci`, `nilai`, `urutan`) VALUES
(15, 'Alamat Lain', 'Isi dengan informasi alamat lainnya', 'NM_ALAMAT_LAIN', 'Jl. Sawo III no. 37, Komp. Villa Sawo, Cipete Utara, Kebayoran Baru, Jakarta Selatan – 12150, Indonesia', 3);
INSERT INTO `ad_konfigurasi` (`kode`, `nama`, `keterangan`, `kunci`, `nilai`, `urutan`) VALUES
(16, 'Nomor Telepon fax', 'Isi dengan nomor telepon FAX', 'NM_FAX', '+62-21-7243109', 6);
INSERT INTO `ad_konfigurasi` (`kode`, `nama`, `keterangan`, `kunci`, `nilai`, `urutan`) VALUES
(17, 'Nama Brand Perusahaan', 'Isi dengan nama brand perusahaan', 'NM_BRAND', 'Sintesys', 2);
INSERT INTO `ad_konfigurasi` (`kode`, `nama`, `keterangan`, `kunci`, `nilai`, `urutan`) VALUES
(18, 'Deskripsi Perusahaan', 'Isi dengan deskripsi perusahaan', 'NM_DESKRIPSI_PT', '<p>Global Solusi Kreasitama, PT, is a highly focused company on strategic alliance with global industry leader. This Strong business access to a range of product and highly specialized and advance expertise of our global strategic partners. \r\nWe integrate these various technologies into a total business solution. One that is specifically designed to help you compete and prosper in the new world of global networked business.</p>', 3);
INSERT INTO `ad_konfigurasi` (`kode`, `nama`, `keterangan`, `kunci`, `nilai`, `urutan`) VALUES
(20, 'Goal tujuan', 'Isi dengan tujuan yang akan dicapai', 'NM_GOAL_PT', '<p>SMART, PROACTIVE, RESPONSIVE</p>\r\n\r\n<p>We are an award-winning team of digital marketing experts, developers & problem solvers all working around the clock to offer the most powerful solution for you and your business.</p>', 3);

-- --------------------------------------------------------

--
-- Table structure for table `ad_log`
--

CREATE TABLE `ad_log` (
  `logid` bigint(20) NOT NULL COMMENT 'The log ID',
  `logdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'The log date',
  `type` enum('error','audit') NOT NULL,
  `page` varchar(50) NOT NULL,
  `lang_id` int(10) NOT NULL DEFAULT '1',
  `function` varchar(50) DEFAULT NULL,
  `message` longtext,
  `requesturi` varchar(2000) DEFAULT NULL,
  `remoteAddr` varchar(254) DEFAULT NULL,
  `userid` int(11) NOT NULL DEFAULT '0',
  `email` char(125) DEFAULT NULL,
  `useragent` varchar(254) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ad_menu`
--

CREATE TABLE `ad_menu` (
  `menu_id` int(10) NOT NULL,
  `parent_id` int(10) NOT NULL DEFAULT '0',
  `lang_id` int(10) NOT NULL DEFAULT '1',
  `menu_name` text NOT NULL,
  `is_active` int(1) NOT NULL DEFAULT '0',
  `ordering` int(10) DEFAULT '0',
  `type_id` int(10) DEFAULT NULL,
  `reference_id` int(10) DEFAULT NULL,
  `image` text,
  `date_created` date DEFAULT NULL,
  `level_menu` int(10) NOT NULL DEFAULT '0',
  `menu_url` text
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_menu`
--

INSERT INTO `ad_menu` (`menu_id`, `parent_id`, `lang_id`, `menu_name`, `is_active`, `ordering`, `type_id`, `reference_id`, `image`, `date_created`, `level_menu`, `menu_url`) VALUES
(1, 0, 1, 'Beranda', 1, 1, NULL, 0, NULL, '2016-06-02', 0, 'home');
INSERT INTO `ad_menu` (`menu_id`, `parent_id`, `lang_id`, `menu_name`, `is_active`, `ordering`, `type_id`, `reference_id`, `image`, `date_created`, `level_menu`, `menu_url`) VALUES
(2, 0, 1, 'Fitur', 1, 2, 0, 0, NULL, '2016-06-02', 0, 'feature');
INSERT INTO `ad_menu` (`menu_id`, `parent_id`, `lang_id`, `menu_name`, `is_active`, `ordering`, `type_id`, `reference_id`, `image`, `date_created`, `level_menu`, `menu_url`) VALUES
(7, 0, 1, 'Tentang Kami', 1, 3, NULL, 0, NULL, '2016-06-02', 0, 'about');
INSERT INTO `ad_menu` (`menu_id`, `parent_id`, `lang_id`, `menu_name`, `is_active`, `ordering`, `type_id`, `reference_id`, `image`, `date_created`, `level_menu`, `menu_url`) VALUES
(30, 0, 2, 'Home', 1, 1, NULL, 0, NULL, '2016-06-02', 0, 'home');
INSERT INTO `ad_menu` (`menu_id`, `parent_id`, `lang_id`, `menu_name`, `is_active`, `ordering`, `type_id`, `reference_id`, `image`, `date_created`, `level_menu`, `menu_url`) VALUES
(17, 0, 1, 'Kontak Kami', 1, 5, NULL, 0, NULL, '2016-10-07', 0, 'contact');
INSERT INTO `ad_menu` (`menu_id`, `parent_id`, `lang_id`, `menu_name`, `is_active`, `ordering`, `type_id`, `reference_id`, `image`, `date_created`, `level_menu`, `menu_url`) VALUES
(31, 0, 2, 'Feature', 1, 2, 0, 0, NULL, '2016-06-02', 0, 'feature');
INSERT INTO `ad_menu` (`menu_id`, `parent_id`, `lang_id`, `menu_name`, `is_active`, `ordering`, `type_id`, `reference_id`, `image`, `date_created`, `level_menu`, `menu_url`) VALUES
(32, 0, 2, 'About', 1, 3, NULL, 0, NULL, '2016-06-02', 0, 'about');
INSERT INTO `ad_menu` (`menu_id`, `parent_id`, `lang_id`, `menu_name`, `is_active`, `ordering`, `type_id`, `reference_id`, `image`, `date_created`, `level_menu`, `menu_url`) VALUES
(33, 0, 2, 'Contact', 1, 5, NULL, 0, NULL, '2016-10-07', 0, 'contact');

-- --------------------------------------------------------

--
-- Table structure for table `ad_menu_admin`
--

CREATE TABLE `ad_menu_admin` (
  `kode` int(6) NOT NULL,
  `nama_menu` varchar(35) NOT NULL,
  `link_menu` varchar(75) NOT NULL,
  `modul` varchar(25) DEFAULT NULL,
  `induk` int(6) NOT NULL DEFAULT '0',
  `urutan` int(3) NOT NULL DEFAULT '0',
  `toggle` varchar(20) DEFAULT NULL,
  `ikon` varchar(35) DEFAULT NULL,
  `aktif` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_menu_admin`
--

INSERT INTO `ad_menu_admin` (`kode`, `nama_menu`, `link_menu`, `modul`, `induk`, `urutan`, `toggle`, `ikon`, `aktif`) VALUES
(1, 'Beranda', 'kuwu/dashboard', NULL, 0, 1, 'beranda', 'zmdi-home', 1);
INSERT INTO `ad_menu_admin` (`kode`, `nama_menu`, `link_menu`, `modul`, `induk`, `urutan`, `toggle`, `ikon`, `aktif`) VALUES
(2, 'Artikel', '#', NULL, 0, 2, 'artikel', 'zmdi-book', 1);
INSERT INTO `ad_menu_admin` (`kode`, `nama_menu`, `link_menu`, `modul`, `induk`, `urutan`, `toggle`, `ikon`, `aktif`) VALUES
(3, 'Berita', '#', NULL, 0, 3, 'berita', 'zmdi-library', 0);
INSERT INTO `ad_menu_admin` (`kode`, `nama_menu`, `link_menu`, `modul`, `induk`, `urutan`, `toggle`, `ikon`, `aktif`) VALUES
(4, 'Media', '#', NULL, 0, 6, 'media', 'zmdi-collection-image', 1);
INSERT INTO `ad_menu_admin` (`kode`, `nama_menu`, `link_menu`, `modul`, `induk`, `urutan`, `toggle`, `ikon`, `aktif`) VALUES
(5, 'Slider', '#', NULL, 0, 7, 'slider', 'zmdi-assignment', 1);
INSERT INTO `ad_menu_admin` (`kode`, `nama_menu`, `link_menu`, `modul`, `induk`, `urutan`, `toggle`, `ikon`, `aktif`) VALUES
(6, 'Pengaturan', '#', NULL, 0, 8, 'pengaturan', 'zmdi-settings', 1);
INSERT INTO `ad_menu_admin` (`kode`, `nama_menu`, `link_menu`, `modul`, `induk`, `urutan`, `toggle`, `ikon`, `aktif`) VALUES
(7, 'Logout', 'kuwu/login/logout', NULL, 0, 9, 'logout', 'zmdi-close', 1);
INSERT INTO `ad_menu_admin` (`kode`, `nama_menu`, `link_menu`, `modul`, `induk`, `urutan`, `toggle`, `ikon`, `aktif`) VALUES
(8, 'Daftar Artikel', 'kuwu/artikel', NULL, 2, 1, 'artikel', NULL, 1);
INSERT INTO `ad_menu_admin` (`kode`, `nama_menu`, `link_menu`, `modul`, `induk`, `urutan`, `toggle`, `ikon`, `aktif`) VALUES
(9, 'Kategori', 'kuwu/artikel/kategori', NULL, 2, 2, 'artikelkategori', NULL, 1);
INSERT INTO `ad_menu_admin` (`kode`, `nama_menu`, `link_menu`, `modul`, `induk`, `urutan`, `toggle`, `ikon`, `aktif`) VALUES
(10, 'Approvement', 'kuwu/artikel/approvement', NULL, 2, 3, 'artikelaprove', NULL, 1);
INSERT INTO `ad_menu_admin` (`kode`, `nama_menu`, `link_menu`, `modul`, `induk`, `urutan`, `toggle`, `ikon`, `aktif`) VALUES
(11, 'Daftar Berita', 'kuwu/berita', NULL, 3, 1, 'berita', NULL, 1);
INSERT INTO `ad_menu_admin` (`kode`, `nama_menu`, `link_menu`, `modul`, `induk`, `urutan`, `toggle`, `ikon`, `aktif`) VALUES
(12, 'Kategori', 'kuwu/berita/kategori', NULL, 3, 2, 'beritakategori', NULL, 1);
INSERT INTO `ad_menu_admin` (`kode`, `nama_menu`, `link_menu`, `modul`, `induk`, `urutan`, `toggle`, `ikon`, `aktif`) VALUES
(13, 'Approvement', 'kuwu/berita/approvement', NULL, 3, 3, 'beritaaprove', NULL, 1);
INSERT INTO `ad_menu_admin` (`kode`, `nama_menu`, `link_menu`, `modul`, `induk`, `urutan`, `toggle`, `ikon`, `aktif`) VALUES
(14, 'Photo', 'kuwu/image', NULL, 4, 1, 'photo', NULL, 1);
INSERT INTO `ad_menu_admin` (`kode`, `nama_menu`, `link_menu`, `modul`, `induk`, `urutan`, `toggle`, `ikon`, `aktif`) VALUES
(15, 'Album/Galeri', 'kuwu/galeri', NULL, 4, 2, 'galeri', NULL, 1);
INSERT INTO `ad_menu_admin` (`kode`, `nama_menu`, `link_menu`, `modul`, `induk`, `urutan`, `toggle`, `ikon`, `aktif`) VALUES
(16, 'Daftar Slider', 'kuwu/slider', NULL, 5, 1, 'slider', NULL, 1);
INSERT INTO `ad_menu_admin` (`kode`, `nama_menu`, `link_menu`, `modul`, `induk`, `urutan`, `toggle`, `ikon`, `aktif`) VALUES
(17, 'Approvement', 'kuwu/slider/approvement', NULL, 5, 2, 'slideraprove', NULL, 1);
INSERT INTO `ad_menu_admin` (`kode`, `nama_menu`, `link_menu`, `modul`, `induk`, `urutan`, `toggle`, `ikon`, `aktif`) VALUES
(18, 'Menu', 'kuwu/menu', NULL, 6, 1, 'menu', NULL, 1);
INSERT INTO `ad_menu_admin` (`kode`, `nama_menu`, `link_menu`, `modul`, `induk`, `urutan`, `toggle`, `ikon`, `aktif`) VALUES
(19, 'Pengguna', 'kuwu/pengguna', NULL, 6, 2, 'pengguna', NULL, 1);
INSERT INTO `ad_menu_admin` (`kode`, `nama_menu`, `link_menu`, `modul`, `induk`, `urutan`, `toggle`, `ikon`, `aktif`) VALUES
(20, 'Manajemen Role', 'kuwu/role', NULL, 6, 3, 'role', NULL, 1);
INSERT INTO `ad_menu_admin` (`kode`, `nama_menu`, `link_menu`, `modul`, `induk`, `urutan`, `toggle`, `ikon`, `aktif`) VALUES
(21, 'Backup', 'kuwu/backup', NULL, 6, 4, 'backup', NULL, 1);
INSERT INTO `ad_menu_admin` (`kode`, `nama_menu`, `link_menu`, `modul`, `induk`, `urutan`, `toggle`, `ikon`, `aktif`) VALUES
(22, 'Project', 'kuwu/project', NULL, 0, 5, 'project', 'zmdi-developer-board', 0);
INSERT INTO `ad_menu_admin` (`kode`, `nama_menu`, `link_menu`, `modul`, `induk`, `urutan`, `toggle`, `ikon`, `aktif`) VALUES
(23, 'Product', 'kuwu/product', NULL, 0, 4, 'product', 'zmdi-group-work', 0);

-- --------------------------------------------------------

--
-- Table structure for table `ad_menu_role`
--

CREATE TABLE `ad_menu_role` (
  `kode` int(6) NOT NULL,
  `grup` int(1) NOT NULL,
  `menuid` int(6) NOT NULL,
  `edit` int(1) DEFAULT '0',
  `update` int(1) DEFAULT '0',
  `delete` int(1) DEFAULT '0',
  `btn` int(1) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_menu_role`
--

INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(1, 1, 1, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(2, 1, 2, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(3, 1, 3, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(4, 1, 4, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(5, 1, 5, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(6, 1, 6, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(7, 1, 7, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(8, 1, 8, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(9, 1, 9, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(10, 1, 10, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(11, 1, 11, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(12, 1, 12, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(13, 1, 13, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(14, 1, 14, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(15, 1, 15, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(16, 1, 16, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(17, 1, 17, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(18, 1, 18, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(19, 1, 19, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(20, 1, 20, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(21, 1, 21, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(22, 1, 22, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(23, 1, 23, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(24, 1, 24, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(25, 1, 25, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(26, 1, 26, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(27, 1, 27, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(28, 1, 36, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(29, 1, 29, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(30, 1, 30, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(31, 1, 31, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(32, 1, 32, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(33, 1, 33, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(34, 1, 34, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(35, 1, 35, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(36, 1, 37, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(37, 1, 38, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(38, 1, 39, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(39, 1, 40, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(40, 1, 41, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(41, 1, 42, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(42, 1, 43, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(43, 1, 44, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(44, 1, 45, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(45, 1, 46, 1, 1, 1, 1);
INSERT INTO `ad_menu_role` (`kode`, `grup`, `menuid`, `edit`, `update`, `delete`, `btn`) VALUES
(46, 1, 47, 1, 1, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `ad_polls`
--

CREATE TABLE `ad_polls` (
  `id` int(5) NOT NULL,
  `poll_question` text COLLATE latin1_general_ci,
  `poll_options` text COLLATE latin1_general_ci,
  `page` varchar(200) COLLATE latin1_general_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ad_poll_votes`
--

CREATE TABLE `ad_poll_votes` (
  `id` int(5) NOT NULL,
  `poll_id` int(5) DEFAULT NULL,
  `vote_id` int(5) DEFAULT NULL,
  `ip` varchar(200) COLLATE latin1_general_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ad_product`
--

CREATE TABLE `ad_product` (
  `product_id` int(6) NOT NULL,
  `lang_id` tinyint(2) NOT NULL DEFAULT '1',
  `product_title` varchar(250) NOT NULL,
  `summary` text,
  `content` longtext NOT NULL,
  `type_id` int(2) DEFAULT NULL,
  `cat_id` int(4) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `tags` char(250) CHARACTER SET utf8 DEFAULT NULL,
  `page_title` char(250) CHARACTER SET utf8 DEFAULT NULL,
  `editor_approval` tinyint(1) NOT NULL DEFAULT '1',
  `moderator_approval` tinyint(1) NOT NULL DEFAULT '1',
  `is_published` tinyint(1) NOT NULL DEFAULT '0',
  `publish_date` datetime DEFAULT NULL,
  `read_count` int(6) NOT NULL DEFAULT '0',
  `date_created` datetime NOT NULL,
  `user_created` int(4) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `user_modified` int(4) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_product`
--

INSERT INTO `ad_product` (`product_id`, `lang_id`, `product_title`, `summary`, `content`, `type_id`, `cat_id`, `image`, `tags`, `page_title`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `read_count`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(1, 1, 'Enterprise Service Portal', '', '<p>We are an award-winning team of digital marketing experts, developers &amp; problem solvers all working around the clock to offer the most powerful solution for you and your business</p>', 12, 2, NULL, NULL, '', 1, 1, 1, '2016-07-20 00:00:00', 0, '2016-07-20 00:00:00', 1, '2018-04-25 15:15:00', 1);
INSERT INTO `ad_product` (`product_id`, `lang_id`, `product_title`, `summary`, `content`, `type_id`, `cat_id`, `image`, `tags`, `page_title`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `read_count`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(2, 1, 'UMB Interactive', 'Bringing together component subsystems into a whole and ensuring that those subsystems function together', '<p>Scope of Service</p>\n\n<ul>\n	<li>Analysis and design of IT platforms</li>\n	<li>Implementation and migration of IT solutions</li>\n	<li>Supply of equipment and software</li>\n	<li>Virtualization of physical environments</li>\n	<li>Consulting services in the field of business process integration</li>\n	<li>Consulting services in the area of IT systems integration</li>\n	<li>Implementation and post-implementation support</li>\n	<li>High Availability Solutions (full-service design, implementation and administration of high performance clusters, high availability clusters and mixed)</li>\n</ul>\n\n<p>Benefits</p>\n\n<ul>\n	<li>Optimization of business processes through the increased exchange of information between different IT systems</li>\n	<li>Increased productivity in the company through access to all the resources of the organization</li>\n	<li>More thorough job analysis and reporting systems to ensure access to a wider range of data</li>\n	<li>Ensuring the smooth flow of information between different systems and areas of the company</li>\n</ul>\n\n<p></p>\n', 12, 1, NULL, 'Glosika', 'icon-network', 1, 1, 1, '2018-04-16 00:00:00', 0, '2018-07-17 00:00:00', 1, '2018-04-26 05:11:59', 1);
INSERT INTO `ad_product` (`product_id`, `lang_id`, `product_title`, `summary`, `content`, `type_id`, `cat_id`, `image`, `tags`, `page_title`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `read_count`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(3, 1, 'Interactive SMS', 'an extremely cost efficient way to set up a communication channel between you and your audience or consumer target group from their mobile phone, starting with a designated keyword, to a designated short code', '<h2>Platform</h2>\r\n\r\n<ul>\r\n	<li><strong>SMS Gateway API</strong> : Integrate SMS gateway with your website or software using SMS API tools and add text messaging to your business workflow.</li>\r\n	<li><strong>SMS Chat</strong> : Send and receive instant text messages with our online SMS chat. It is perfect for remote communication with staff and customers.</li>\r\n	<li><strong>SMS Broadcast</strong> : sent to a distribution list address is immediately forwarded as a text message to all mobile numbers saved in the list.</li>\r\n	<li><strong>Receive SMS Online</strong> : Use our dedicated or shared SMS numbers to receive inbound SMS and replies to your text messages from customers and staff.</li>\r\n</ul>\r\n\r\n<p></p>\r\n', 12, 1, 'interaktif_sms.png', '', '', 1, 1, 1, '2018-04-27 09:44:30', 0, '2016-07-20 00:00:00', 1, '2018-04-27 09:44:30', 1);
INSERT INTO `ad_product` (`product_id`, `lang_id`, `product_title`, `summary`, `content`, `type_id`, `cat_id`, `image`, `tags`, `page_title`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `read_count`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(4, 1, 'Digital Marketing', 'Information in an easy to understand dashboards including consumer journey, audience segments, campaign KPI’s among others', '<h2>Scope of Service</h2>\r\n\r\n<ul>\r\n	<li>CRM strategy</li>\r\n	<li>Search engine optimization</li>\r\n	<li>Application analytics</li>\r\n	<li>Web analytics</li>\r\n	<li>Content Marketing</li>\r\n	<li>Campaign analytics</li>\r\n	<li>Rich banner placement</li>\r\n	<li>Digital media planning</li>\r\n	<li>Goal setting &amp; benchmarking</li>\r\n</ul>\r\n\r\n<h2>Benefits</h2>\r\n\r\n<ul>\r\n	<li>Information in an easy to understand dashboards including consumer journey, audience segments, campaign KPI&rsquo;s among others.</li>\r\n	<li>Identifying the right objective for your campaign to audience selection, all the way through merchant and rewards management, to build smarter customer experiences</li>\r\n	<li>Concentrate on recognized market performance indicators, opens and a few other milestones along the consumer journey which provides fun, interactive, surprise and delight mechanisms to create deeper engagements</li>\r\n	<li>Performing and having the ability to tweak and manage campaigns for better results.</li>\r\n	<li>Ability to drive viral social campaigns through your customer&rsquo;s network and tribes</li>\r\n</ul>\r\n\r\n<p></p>\r\n', 12, 3, 'digital_marketingjpg.jpeg', 'Parallax Two', '', 0, 0, 1, '2018-04-27 09:51:41', 0, '2016-07-20 00:00:00', 1, '2018-04-27 09:51:41', 1);
INSERT INTO `ad_product` (`product_id`, `lang_id`, `product_title`, `summary`, `content`, `type_id`, `cat_id`, `image`, `tags`, `page_title`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `read_count`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(5, 1, 'Supply Chain Management', 'The collection of methodologies, theories, and practices that go towards keeping a supply chain running and improving its efficiency for the benefit of most', '<p>Design, planning, execution, control, and monitoring of supply chain activities with the objective of creating net value, building a competitive infrastructure, leveraging logistics aspect, synchronizing supply with demand, and measuring performance .</p>\r\n\r\n<h2>Benefits</h2>\r\n\r\n<ul>\r\n	<li>Adjust more dynamically to the fluctuating economies, emergency markets, and shorter product life-cycles.</li>\r\n	<li>Responsiveness to the actual customer&#39;s requirements</li>\r\n	<li>Adds up to the coordination and collaboration with shipping and transport companies, vendors, and suppliers.</li>\r\n	<li>Lower any delays in processes</li>\r\n	<li>Enhanced supply chain network</li>\r\n	<li>Boost cooperation level</li>\r\n</ul>\r\n\r\n<p></p>\r\n', 12, 4, 'supply_chain_management2jpg.jpeg', 'Parralax Two', '', 0, 0, 1, '2018-04-27 09:56:28', 0, '2016-07-20 00:00:00', 1, '2018-04-27 09:56:28', 1);
INSERT INTO `ad_product` (`product_id`, `lang_id`, `product_title`, `summary`, `content`, `type_id`, `cat_id`, `image`, `tags`, `page_title`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `read_count`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(6, 1, 'Brand Activations', 'Advertising not just a mere dissemination of information about your products and service to target  audience, it about building your brand image and awarness.', '<p>Advertising not just a mere dissemination of information about your products and service to target&nbsp; audience, it about building your brand image and awarness.</p>\r\n\r\n<p>We design and conduct media advertising strategies for indoor , outdoor dor those&nbsp; who are ready&nbsp; to take their business to a new level or launch a new product&nbsp; or service.</p>\r\n\r\n<h2>Out service are:</h2>\r\n\r\n<ul>\r\n	<li>Billboard Baligho</li>\r\n	<li>Shop Design</li>\r\n	<li>Road Sign</li>\r\n	<li>Shop Panel</li>\r\n	<li>Neon Box</li>\r\n	<li>30 Letter Signage</li>\r\n	<li>Vehicle Graphic</li>\r\n	<li>Banner</li>\r\n	<li>Product Display Stand</li>\r\n	<li>Painting and Branding</li>\r\n</ul>\r\n', 13, 5, 'brand_activation.png', 'Parralax Two', '', 0, 0, 1, '2018-04-27 10:08:22', 0, '2016-07-20 00:00:00', 1, '2018-04-27 10:08:22', 1);
INSERT INTO `ad_product` (`product_id`, `lang_id`, `product_title`, `summary`, `content`, `type_id`, `cat_id`, `image`, `tags`, `page_title`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `read_count`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(7, 1, 'Brand Strategy', 'Brand Strategy', '<p>Brand Strategy</p>\r\n', 13, 6, NULL, '', 'System Integrator', 1, 0, 1, '2018-04-27 10:11:06', 0, '2016-07-20 00:00:00', 1, '2018-04-27 10:11:06', 1);
INSERT INTO `ad_product` (`product_id`, `lang_id`, `product_title`, `summary`, `content`, `type_id`, `cat_id`, `image`, `tags`, `page_title`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `read_count`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(8, 1, 'B2C Telemarketing', 'Business to Consumer telemarketing can be an important part in your customer communication and marketing strategy but it has to be undertaken properly. The important thing is to focus on the key steps that can be put in place to help ensure your campaign is undertaken as professionally as possible and delivers a strong return on investment', '<p>Business to Consumer telemarketing can be an important part in your customer communication and marketing strategy but it has to be undertaken properly. The important thing is to focus on the key steps that can be put in place to help ensure your campaign is undertaken as professionally as possible and delivers a strong return on investment.</p>\r\n\r\n<ul>\r\n	<li>Accurate prospecting and quality of data is critical to the success or otherwise of any customer communication strategy.</li>\r\n	<li>Warm prospecting will always deliver greater returns&nbsp; so if you have an existing database of clients then this is always a good place to start.</li>\r\n	<li>Ensure your product or service is well targeted to the consumer profile. There is absolutely no point in contacting people who are likely to have little requirement or need for your products or services.</li>\r\n	<li>Allocate suitable time in preparing your approach and communication strategy.</li>\r\n</ul>\r\n', 14, 9, NULL, NULL, NULL, 1, 1, 1, '2018-04-27 10:20:27', 0, '0000-00-00 00:00:00', 1, '2018-04-27 10:20:27', 1);
INSERT INTO `ad_product` (`product_id`, `lang_id`, `product_title`, `summary`, `content`, `type_id`, `cat_id`, `image`, `tags`, `page_title`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `read_count`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(9, 1, 'B2B TELEMARKETING', 'Our advantage in telemarketing with employees ready to take orders in presenting a new and dedicated interface to your customers', '<p>Our advantage in telemarketing with employees ready to take orders in presenting a new and dedicated interface to your customers. We can design a campaign that lets you take advantage of every opportunity and achieve major business growth and development.<br />\r\nTalking directly to your customer base is an affordable and effective way to gain maximum marketing impact and get valuable and immediate feedback from your target audience. Following appropriate training and working closely with you and your team, we can strategically make the most of every sales opportunity and promote your reputation as a customer focused company.</p>\r\n\r\n<p></p>\r\n', 14, 9, NULL, NULL, NULL, 1, 1, 1, '2018-04-27 10:21:51', 0, '0000-00-00 00:00:00', 1, '2018-04-27 10:21:51', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ad_profil`
--

CREATE TABLE `ad_profil` (
  `kode` int(11) NOT NULL,
  `kode_user` int(4) NOT NULL,
  `nama_lengkap` varchar(175) DEFAULT NULL,
  `lahir` date DEFAULT NULL,
  `status` varchar(25) DEFAULT NULL,
  `kelamin` varchar(15) DEFAULT NULL,
  `alamat` text,
  `pekerjaan` varchar(50) DEFAULT NULL,
  `telepon` varchar(20) DEFAULT NULL,
  `hp` varchar(20) DEFAULT NULL,
  `deksripsi` text,
  `twitter` varchar(75) DEFAULT NULL,
  `facebook` varchar(125) DEFAULT NULL,
  `email` varchar(125) DEFAULT NULL,
  `photo` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_profil`
--

INSERT INTO `ad_profil` (`kode`, `kode_user`, `nama_lengkap`, `lahir`, `status`, `kelamin`, `alamat`, `pekerjaan`, `telepon`, `hp`, `deksripsi`, `twitter`, `facebook`, `email`, `photo`) VALUES
(1, 1, 'aep darmawan', '1973-08-23', 'Menikah', 'Laki-laki', 'Jl. Telegraph No.4 \r\nPerumahan Telkom, Cibeureum - Cimahi\r\nJawa Barat', 'Maen Game', '0899999888', '08988112222', 'Ubah isian informasi tantang anda ', '@betmen', NULL, NULL, 'shiluet-01.png');

-- --------------------------------------------------------

--
-- Table structure for table `ad_project`
--

CREATE TABLE `ad_project` (
  `project_id` int(6) NOT NULL,
  `lang_id` tinyint(2) NOT NULL DEFAULT '1',
  `company_name` char(125) NOT NULL,
  `project_date` date DEFAULT NULL,
  `project_title` varchar(250) NOT NULL,
  `summary` text,
  `content` longtext NOT NULL,
  `type_id` int(2) NOT NULL,
  `cat_id` int(4) NOT NULL,
  `product_id` int(6) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `tags` char(250) CHARACTER SET utf8 DEFAULT NULL,
  `page_title` char(250) CHARACTER SET utf8 DEFAULT NULL,
  `read_count` int(6) NOT NULL DEFAULT '0',
  `editor_approval` tinyint(1) NOT NULL DEFAULT '1',
  `moderator_approval` tinyint(1) NOT NULL DEFAULT '1',
  `is_published` tinyint(1) NOT NULL DEFAULT '0',
  `publish_date` datetime DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `user_created` int(4) NOT NULL,
  `date_modified` datetime DEFAULT NULL,
  `user_modified` int(4) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_project`
--

INSERT INTO `ad_project` (`project_id`, `lang_id`, `company_name`, `project_date`, `project_title`, `summary`, `content`, `type_id`, `cat_id`, `product_id`, `image`, `tags`, `page_title`, `read_count`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(1, 1, 'Company #1', '2018-02-07', 'Project Smarts', 'Sed tortor. Curabitur molestie. Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros', '<p>We are an award-winning team of digital marketing experts, developers &amp; problem solvers all working around the clock to offer the most powerful solution for you and your business</p>\n', 12, 1, 1, 'dashboard-00.png', 'Technology', '', 0, 1, 1, 1, '2018-04-28 08:02:36', '2016-07-20 00:00:00', 1, '2018-04-28 08:02:36', 1);
INSERT INTO `ad_project` (`project_id`, `lang_id`, `company_name`, `project_date`, `project_title`, `summary`, `content`, `type_id`, `cat_id`, `product_id`, `image`, `tags`, `page_title`, `read_count`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(2, 1, 'Company #2', '2017-10-26', 'Developing Mobile Apps', 'Suspendisse lacinia. Curabitur ac tortor ut ipsum egestas elementum. Nunc imperdiet gravida mauris.', '<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas feugiat consequat diam. Maecenas metus. Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor. Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit. Nulla pretium mi et risus. Fusce mi pede, tempor id, cursus ac, ullamcorper nec, enim. Sed tortor. Curabitur molestie. Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum, est ut placerat elementum, lectus nisl aliquam velit, tempor aliquam eros nunc nonummy metus. In eros metus, gravida a, gravida sed, lobortis id, turpis. Ut ultrices, ipsum at venenatis fringilla, sem nulla lacinia tellus, eget aliquet turpis mauris non enim. Nam turpis. Suspendisse lacinia. Curabitur ac tortor ut ipsum egestas elementum. Nunc imperdiet gravida mauris.</p>\r\n', 12, 2, 5, 'snapshot_20170731jpg.jpeg', 'Technology', 'Struktur Organisasi', 0, 1, 1, 1, '2018-04-28 11:22:18', '2018-07-17 00:00:00', 1, '2018-04-28 11:22:18', 1);
INSERT INTO `ad_project` (`project_id`, `lang_id`, `company_name`, `project_date`, `project_title`, `summary`, `content`, `type_id`, `cat_id`, `product_id`, `image`, `tags`, `page_title`, `read_count`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(3, 1, 'Company Name #23', '2017-07-15', 'Just Project Example #1', 'Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor. Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit', '<p>Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor. Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit</p>\r\n', 3, 0, 6, NULL, 'Parallax Two', 'Mahasiswa Penerima BPPDN DIKTI', 0, 1, 1, 1, '2018-04-28 11:28:16', '2016-07-20 13:42:06', 1, '2018-04-28 11:28:16', 1);
INSERT INTO `ad_project` (`project_id`, `lang_id`, `company_name`, `project_date`, `project_title`, `summary`, `content`, `type_id`, `cat_id`, `product_id`, `image`, `tags`, `page_title`, `read_count`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(4, 1, 'Company Name #500', '2016-06-29', 'Just Project Example #2', 'Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit. Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor.', '<p>Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit. Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor.</p>\r\n', 3, 0, 2, NULL, 'Parallax Two', '', 0, 1, 1, 1, '2018-04-28 11:29:36', '2016-07-20 00:00:00', 1, '2018-04-28 11:29:36', 1);
INSERT INTO `ad_project` (`project_id`, `lang_id`, `company_name`, `project_date`, `project_title`, `summary`, `content`, `type_id`, `cat_id`, `product_id`, `image`, `tags`, `page_title`, `read_count`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(5, 1, 'Company Name #922 B', '2018-01-10', 'Just Project Example #3', 'Curabitur molestie. Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula', '<p>Curabitur molestie. Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula</p>\r\n', 3, 0, 4, NULL, 'Parralax Two', '', 0, 1, 1, 1, '2018-04-28 11:30:52', '2016-07-20 00:00:00', 1, '2018-04-28 11:30:52', 1);
INSERT INTO `ad_project` (`project_id`, `lang_id`, `company_name`, `project_date`, `project_title`, `summary`, `content`, `type_id`, `cat_id`, `product_id`, `image`, `tags`, `page_title`, `read_count`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(6, 1, '', NULL, 'Surat Edaran Dirjen Dikti', 'Sehubungan dengan istilah literitas bidang ilmu yang berkaitan dengan pembukaan program studi, penerimaan dosen baru, dan kenaikan jenjang jabatan.', '<p class=\"post-meta\"><span class=\"date\">Tgl Mei 24, 2016</span></p>\r\n\r\n<div class=\"post-excerpt\">\r\n<p>Sehubungan dengan istilah literitas bidang ilmu yang berkaitan dengan pembukaan program studi, penerimaan dosen baru, dan kenaikan jenjang jabatan.</p>\r\n</div>\r\n', 3, 0, 0, NULL, 'Parralax Two', '', 0, 1, 1, 0, NULL, '2016-07-20 00:00:00', 1, '2016-08-26 10:08:07', 1);
INSERT INTO `ad_project` (`project_id`, `lang_id`, `company_name`, `project_date`, `project_title`, `summary`, `content`, `type_id`, `cat_id`, `product_id`, `image`, `tags`, `page_title`, `read_count`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(7, 1, 'Company #1', '2018-03-08', 'Project Smarts v2', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas feugiat consequat diam. Maecenas metus. Vivamus diam purus, cursus a, commodo non', '<p>&quot;Penyelenggaraan Pascasarjana di Universitas Padjadjaran secara resmi dimulai dengan acara pembukaan perkuliahan pada tanggal 21 Juli 1979 oleh Prof. Dr, R.A. Tisnaamidjaja, Dirjen Dikti Departemen Pendidikan dan Kebudayaan RI. Pada saat dimulai, tahun akademik 1979/1980, program ini baru memilki satu program studi, yaitu Program Studi Magister (S2) Ilmu Tanaman (Agronomi). Kemudian berkembang menjadi Fakultas Pascasarjana yang menyelenggarakan tiga program pendidikan yaitu Program Pendidikan Magister (S2), Program Pendidikan Doktor (S3), dan Program Pendidikan Spesialis I (Sp I), dikukuhkan melalui SK Presiden RI No. 47 tahun 1982 tanggal 7 September 1982 mengenai susunan organisasi Universitas Padjadjaran, dan SK Menteri Pendidikan dan Kebudayaan RI No. 133/0/1983 tentang organisasi dan tata kerja Universitas Padjadjaran.</p>\r\n\r\n<p>Mulai tahun 1989 status penyelenggaraan Fakultas Pascasarjana berubah menjadi Program Pascasarjana, didasarkan pada Undang-undang No. 2/1989 dan PP No. 30/1990 serta peraturan pelaksanaannya, yaitu SK Menteri Pendidikan dan Kebudayan No. 0311/0/1991 dan No. 0436/0/1992 (Statuta Universitas Padjadjaran), No. 036/U/1993 (Gelar dan Sebutan Lulusan PT), dan No. 056/U/1994 (Pedoman Penyusunan Kurikulum Pendidikan Tinggi dan Penilaian Hasil Belajar Mahasiswa). Pada masa awal penyelenggaraan, pengelolaan Program Magister dilakukan oleh fakultas bidang atau cabang ilmu yang bersangkutan. Pengelolaan itu dikoordinasikan oleh Tim Manajemen di tingkat Universitas yang juga mengelola Program Doktor. Dengan adanya Fakultas Pascasarjana, pengelola Program Magister dan Program Doktor dilakukan oleh Fakultas itu.</p>\r\n\r\n<p>Dengan diterbitkannya Keputusan Menteri Pendidikan dan Kebudayaan Republik Indonesia No.0311/0/1991, pengelolaan Program Magister dan Program Doktor dipimpin oleh Direktur Program Pascasarjana yang bertanggung jawab kepada Rektor. Berdasarkan PP No. 60 Tahun 1999 dan melalui Keputusan Rektor Universitas Padjadjaran, Nomor 1307/H6.1/KEP/HK/2008, secara resmi mulai Februari 2009, hanya program studi multidisiplin saja yang dikoordinasi oleh Program Pascasarjana, sedangkan program studi pascasarjana mono/oligo-disiplin dikoordinasi oleh fakultas yang sama atau sesuai. Pada tahun 2013 sesuai Permendikbud 46 tahun 2013 tentang OTK Unpad, Pascasarjana merupakan unsur pelaksana akademik yang melaksanakan sebagian tugas dan fungsi UNPAD yang berada di bawah dan bertanggung jawab kepada Rektor.</p>\r\n\r\n<p>Pascasarjana mempunyai tugas melaksanakan pendidikan program magister dan program doktor untuk bidang ilmu interdisiplin dan melaksanakan penjaminan mutu program magister dan program doktor yang diselenggarakan oleh fakultas.Pada perkembangannya saat ini dengan keluarnya PP RI nomor 80 tahun 2014, tanggal 17 Oktiober 2014 tentang Universitas Padjadjaran menjadi PTN BH (Badan Hukum), dilanjutkan dengan Peraturan Pemerintah Nomor 51 Tahun 2015 tentang Statuta Universitas Padjadjaran, dan akhirnya Peraturan Rektor Nomor 70 Tahun 2015 tentang Organisasi dan Tata Kerja Pengelola Unpad, Pascasarjana berubah menjadi Sekolah Pascasarjana. Sekolah adalah unsur pelaksana akademik setingkat Fakultas yang bertugas menyelenggarakan dan/atau mengoordinasikan program pascasarjana multidisiplin.</p>\r\n', 12, 4, 1, 'dudi_muttaqienjpg.jpeg', 'Business Plan', 'Tentang Kami', 0, 1, 1, 1, '2018-04-28 11:26:50', '2016-07-20 00:00:00', 1, '2018-04-28 11:26:50', 1);
INSERT INTO `ad_project` (`project_id`, `lang_id`, `company_name`, `project_date`, `project_title`, `summary`, `content`, `type_id`, `cat_id`, `product_id`, `image`, `tags`, `page_title`, `read_count`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(8, 1, 'Company #3', '2018-04-10', 'Developing another', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas feugiat consequat diam. Maecenas metus. Vivamus diam purus, cursus a, commodo non, facilisis vitae', '<h3>Visi</h3>\r\n\r\n<p>Pada tahun 2026 menjadi institusi pendidikan berciri multidisiplin, interdisiplin dan transdisiplin yang mampu merespon persaingan global dan merespon pembangunan berkelanjutan di masyarakat</p>\r\n\r\n<h3>Misi</h3>\r\n\r\n<p>Menyelenggarakan pendidikan berbasis riset bertaraf nasional, regional dan internasional, yang berorientasi pada Pola Ilmiah Pokok dengan mengintegrasikan berbagai perspektif ilmu sosial/humaniora dan ilmu alam serta ilmu keteknikan ke dalam pendekatan holistik-integratif</p>\r\n\r\n<blockquote>\r\n<ol>\r\n	<li><span style=\"font-size:14px;\">Menyelenggarakan riset berorientasi produk dan kebijakan (policy-based research) yang diperlukan oleh pemerintah, pelaku usaha dan masyaraka.t</span></li>\r\n	<li><span style=\"font-size:14px;\">Menyelenggarakan tata kelola lembaga riset dan pendidikan tinggi yang kredibel, transparan, akuntabel, bertanggungjawab, dan adil.</span></li>\r\n	<li><span style=\"font-size:14px;\">Menghasilkan insan akademik yang kompeten dan menjunjung tinggi etika lingkungan serta keluhuran budaya lokal dan budaya nasional.</span></li>\r\n	<li><span style=\"font-size:14px;\">Menjalin hubungan kerjasama strategis dengan pemerintah, pelaku usaha, dan masyarakat serta perguruan tinggi lain, baik didalam negeri maupun luar negeri, secara berkesinambungan dengan menerapkan prinsip kesetaraan, kemitraan dan saling percaya.</span></li>\r\n</ol>\r\n</blockquote>\r\n\r\n<h3>Tujuan Pendidikan Program Magister diarahkan pada hasil lulusan yang memiliki kualifikasi</h3>\r\n\r\n<blockquote>\r\n<ol>\r\n	<li><span style=\"font-size:14px;\">Terwujudnya kurikulum dan model pembelajaran berbasis riset yang mampu mengembangkan keilmuan serta memenuhi tuntutan kompetensi dari pengguna lulusan.</span></li>\r\n	<li><span style=\"font-size:14px;\">Meningkatkan kegiatan riset dan pendidikan berorientasi pada produk (hilirisasi) dan kebijakan bertaraf nasional, regional dan internasional.</span></li>\r\n	<li><span style=\"font-size:14px;\">Terwujudnya sistem penjaminan mutu (quality assurance) untuk memastikan keberhasilan pembelajaran kurikulum berbasis riset.</span></li>\r\n	<li><span style=\"font-size:14px;\">Terwujudnya tata kelola pendidikan tinggi yang kredibel, transparan, akuntabel, bertanggungjawab, dan adil.</span></li>\r\n	<li><span style=\"font-size:14px;\">Menghasilkan lulusan yang kompeten dengan pemahaman pendekatan multi-perspektif dan penerapan nilai-nilai budaya lokal sebagai sumber keunggulan insan akademik.</span></li>\r\n	<li><span style=\"font-size:14px;\">Terwujudnya Sekolah Pascasarjana sebagai pusat keunggulan (center of excellence) di bidang ilmu lingkungan di tingkat nasional, regional, dan internasional.</span></li>\r\n	<li><span style=\"font-size:14px;\">Terwujudnya kemitraan dengan berbagai organisasi dalam dan luar negeri untuk teraihnya sumberdaya finansial mandiri untuk tercapainya stabilitas penyelenggaraan riset dan pendidikan.</span></li>\r\n</ol>\r\n</blockquote>\r\n', 12, 0, 1, 'drunch2jpg.jpeg', 'Marketing', 'Tentang Kami', 0, 1, 1, 1, '2018-04-28 11:26:21', '2017-03-03 09:44:39', 1, '2018-04-28 11:26:21', 1);
INSERT INTO `ad_project` (`project_id`, `lang_id`, `company_name`, `project_date`, `project_title`, `summary`, `content`, `type_id`, `cat_id`, `product_id`, `image`, `tags`, `page_title`, `read_count`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(9, 1, 'Company #4', '2018-02-14', 'Project Smart', 'Fusce mi pede, tempor id, cursus ac, ullamcorper nec, enim. Sed tortor. Curabitur molestie. Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum', '<p class=\"testimonial-content mobile-four\">1. Magister Ilmu Lingkungan<br />\r\n2. Magister Ilmu Bioteknologi<br />\r\n3. Magister Pariwisata Berkelanjutan<br />\r\n4. Magister Inovasi Regional<br />\r\n5. Magister Manajemen Sumberdaya Hayati<br />\r\n6. Magister Ilmu Berkelanjutan</p>\r\n\r\n<p class=\"testimonial-signature mobile-four\">Pascasarjana<span> UNPAD</span></p>\r\n', 13, 0, 6, 'screenshot-2018-1-29_home.png', 'Business Plan', 'Program Studi', 0, 1, 1, 1, '2018-04-28 11:23:49', '2016-08-19 00:00:00', 1, '2018-04-28 11:23:49', 1);
INSERT INTO `ad_project` (`project_id`, `lang_id`, `company_name`, `project_date`, `project_title`, `summary`, `content`, `type_id`, `cat_id`, `product_id`, `image`, `tags`, `page_title`, `read_count`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(10, 1, 'Company #5', '2017-06-06', 'Branding Party', 'Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus', '<p>Sekolah Pascasarjana (SPs) sebagai unit lembaga penyelenggara pendidikan tinggi di Unpad setingkat fakultas yang mempunyai peran ikut serta meningkatkan taraf pendidikan rakyat sebagaimana dinyatakan dalam mukadimah Undang-Undang Dasar 45 bahwa, Negara bertujuan mencerdaskan kehidupan bangsa. Statuta Unpad juga mengamanahkan SPs harus mampu mendidik peserta didik menjadi anggota masyarakat yang memiliki kemampuan akademik untuk menerapkan, mengembangkan, dan memperkaya khasanah ilmu pengetahuan, teknologi, dan kesenian khususnya keilmuan secara lengkap multi disiplin, inter disiplin dan transdisiplin guna meningkatkan taraf kehidupan masyarakat dan bangsa.</p>\r\n', 13, 0, 7, 'capture-phpinfojpg.jpeg', 'Event Organizer', 'Tentang Kami', 0, 1, 1, 1, '2018-04-28 11:23:08', '2016-08-19 00:00:00', 1, '2018-04-28 11:23:08', 1);
INSERT INTO `ad_project` (`project_id`, `lang_id`, `company_name`, `project_date`, `project_title`, `summary`, `content`, `type_id`, `cat_id`, `product_id`, `image`, `tags`, `page_title`, `read_count`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(11, 1, 'Company #6', '2018-01-04', 'Blue Print 3D Model', 'Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum,', '<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas feugiat consequat diam. Maecenas metus. Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor. Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit. Nulla pretium mi et risus. Fusce mi pede, tempor id, cursus ac, ullamcorper nec, enim. Sed tortor. Curabitur molestie. Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum, est ut placerat elementum, lectus nisl aliquam velit, tempor aliquam eros nunc nonummy metus. In eros metus, gravida a, gravida sed, lobortis id, turpis. Ut ultrices, ipsum at venenatis fringilla, sem nulla lacinia tellus, eget aliquet turpis mauris non enim. Nam turpis. Suspendisse lacinia. Curabitur ac tortor ut ipsum egestas elementum. Nunc imperdiet gravida mauris.</p>\r\n', 14, 0, 8, 'aplikasi-spal.png', 'Technology', 'Program Studi', 0, 1, 1, 1, '2018-04-28 17:21:10', '2016-08-19 00:00:00', 1, '2018-04-28 17:21:10', 1);
INSERT INTO `ad_project` (`project_id`, `lang_id`, `company_name`, `project_date`, `project_title`, `summary`, `content`, `type_id`, `cat_id`, `product_id`, `image`, `tags`, `page_title`, `read_count`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(13, 1, '', '0000-00-00', 'Magister Ilmu Lingkungan', '', '<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas feugiat consequat diam. Maecenas metus. Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor. Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit. Nulla pretium mi et risus. Fusce mi pede, tempor id, cursus ac, ullamcorper nec, enim. Sed tortor. Curabitur molestie. Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum, est ut placerat elementum, lectus nisl aliquam velit, tempor aliquam eros nunc nonummy metus. In eros metus, gravida a, gravida sed, lobortis id, turpis. Ut ultrices, ipsum at venenatis fringilla, sem nulla lacinia tellus, eget aliquet turpis mauris non enim. Nam turpis. Suspendisse lacinia. Curabitur ac tortor ut ipsum egestas elementum. Nunc imperdiet gravida mauris.</p>\r\n', 2, 0, 0, NULL, 'Program Studi Magister', 'Program Studi', 0, 1, 1, 0, NULL, '2016-08-19 00:00:00', 1, '2018-04-28 11:31:21', 1);
INSERT INTO `ad_project` (`project_id`, `lang_id`, `company_name`, `project_date`, `project_title`, `summary`, `content`, `type_id`, `cat_id`, `product_id`, `image`, `tags`, `page_title`, `read_count`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(12, 1, '', '0000-00-00', 'Doktor Bioteknologi', '', '<p><span class=\"dropcap-1\">Edit L</span>oremipsum dolor sit amet, consectetuer adipiscing elit. Maecenas feugiat consequat diam. Maecenas metus. Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor. Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit. Nulla pretium mi et risus. Fusce mi pede, tempor id, cursus ac, ullamcorper nec, enim. Sed tortor. Curabitur molestie. Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum, est ut placerat elementum, lectus nisl aliquam velit, tempor aliquam eros nunc nonummy metus. In eros metus, gravida a, gravida sed, lobortis id, turpis. Ut ultrices, ipsum at venenatis fringilla, sem nulla lacinia tellus, eget aliquet turpis mauris non enim. Nam turpis. Suspendisse lacinia. Curabitur ac tortor ut ipsum egestas elementum. Nunc imperdiet gravida mauris.</p>\r\n', 2, 0, 0, NULL, 'Program Studi DOKTOR', 'Program Studi', 0, 1, 1, 0, NULL, '2016-08-19 00:00:00', 1, '2018-04-28 11:31:10', 1);
INSERT INTO `ad_project` (`project_id`, `lang_id`, `company_name`, `project_date`, `project_title`, `summary`, `content`, `type_id`, `cat_id`, `product_id`, `image`, `tags`, `page_title`, `read_count`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(14, 1, '', '0000-00-00', 'Magister Ilmu Bioteknologi', '', '<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas feugiat consequat diam. Maecenas metus. Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor. Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit. Nulla pretium mi et risus. Fusce mi pede, tempor id, cursus ac, ullamcorper nec, enim. Sed tortor. Curabitur molestie. Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum, est ut placerat elementum, lectus nisl aliquam velit, tempor aliquam eros nunc nonummy metus. In eros metus, gravida a, gravida sed, lobortis id, turpis. Ut ultrices, ipsum at venenatis fringilla, sem nulla lacinia tellus, eget aliquet turpis mauris non enim. Nam turpis. Suspendisse lacinia. Curabitur ac tortor ut ipsum egestas elementum. Nunc imperdiet gravida mauris.</p>\r\n', 2, 0, 0, NULL, 'Program Studi Magister', 'Program Studi', 0, 1, 1, 0, NULL, '2016-08-18 00:00:00', 1, '2018-04-28 11:31:32', 1);
INSERT INTO `ad_project` (`project_id`, `lang_id`, `company_name`, `project_date`, `project_title`, `summary`, `content`, `type_id`, `cat_id`, `product_id`, `image`, `tags`, `page_title`, `read_count`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(15, 1, '', '0000-00-00', 'Magister Pariwisata Berkelanjutan', '', '<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas feugiat consequat diam. Maecenas metus. Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor. Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit. Nulla pretium mi et risus. Fusce mi pede, tempor id, cursus ac, ullamcorper nec, enim. Sed tortor. Curabitur molestie. Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum, est ut placerat elementum, lectus nisl aliquam velit, tempor aliquam eros nunc nonummy metus. In eros metus, gravida a, gravida sed, lobortis id, turpis. Ut ultrices, ipsum at venenatis fringilla, sem nulla lacinia tellus, eget aliquet turpis mauris non enim. Nam turpis. Suspendisse lacinia. Curabitur ac tortor ut ipsum egestas elementum. Nunc imperdiet gravida mauris.</p>\r\n', 2, 0, 0, NULL, 'Program Studi Magister', 'Program Studi', 0, 1, 1, 0, NULL, '2016-08-19 00:00:00', 1, '2018-04-28 11:31:54', 1);
INSERT INTO `ad_project` (`project_id`, `lang_id`, `company_name`, `project_date`, `project_title`, `summary`, `content`, `type_id`, `cat_id`, `product_id`, `image`, `tags`, `page_title`, `read_count`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(16, 1, '', '0000-00-00', 'Magister Inovasi Regional', '', '<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas feugiat consequat diam. Maecenas metus. Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor. Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit. Nulla pretium mi et risus. Fusce mi pede, tempor id, cursus ac, ullamcorper nec, enim. Sed tortor. Curabitur molestie. Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum, est ut placerat elementum, lectus nisl aliquam velit, tempor aliquam eros nunc nonummy metus. In eros metus, gravida a, gravida sed, lobortis id, turpis. Ut ultrices, ipsum at venenatis fringilla, sem nulla lacinia tellus, eget aliquet turpis mauris non enim. Nam turpis. Suspendisse lacinia. Curabitur ac tortor ut ipsum egestas elementum. Nunc imperdiet gravida mauris.</p>\r\n', 2, 0, 0, NULL, 'Program Studi Magister', 'Program Studi', 0, 1, 1, 0, NULL, '2016-08-19 00:00:00', 1, '2018-04-28 11:32:04', 1);
INSERT INTO `ad_project` (`project_id`, `lang_id`, `company_name`, `project_date`, `project_title`, `summary`, `content`, `type_id`, `cat_id`, `product_id`, `image`, `tags`, `page_title`, `read_count`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(17, 1, '', '0000-00-00', 'Magister Manajemen Bioresources', '', '<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas feugiat consequat diam. Maecenas metus. Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor. Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit. Nulla pretium mi et risus. Fusce mi pede, tempor id, cursus ac, ullamcorper nec, enim. Sed tortor. Curabitur molestie. Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum, est ut placerat elementum, lectus nisl aliquam velit, tempor aliquam eros nunc nonummy metus. In eros metus, gravida a, gravida sed, lobortis id, turpis. Ut ultrices, ipsum at venenatis fringilla, sem nulla lacinia tellus, eget aliquet turpis mauris non enim. Nam turpis. Suspendisse lacinia. Curabitur ac tortor ut ipsum egestas elementum. Nunc imperdiet gravida mauris.</p>\r\n', 2, 0, 0, NULL, 'Program Studi Magister', 'Program Studi', 0, 1, 1, 0, NULL, '2016-08-19 00:00:00', 1, '2018-04-28 11:32:15', 1);
INSERT INTO `ad_project` (`project_id`, `lang_id`, `company_name`, `project_date`, `project_title`, `summary`, `content`, `type_id`, `cat_id`, `product_id`, `image`, `tags`, `page_title`, `read_count`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(18, 1, '', '0000-00-00', 'Magister Ilmu Berkelanjutan', '', '<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas feugiat consequat diam. Maecenas metus. Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor. Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit. Nulla pretium mi et risus. Fusce mi pede, tempor id, cursus ac, ullamcorper nec, enim. Sed tortor. Curabitur molestie. Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum, est ut placerat elementum, lectus nisl aliquam velit, tempor aliquam eros nunc nonummy metus. In eros metus, gravida a, gravida sed, lobortis id, turpis. Ut ultrices, ipsum at venenatis fringilla, sem nulla lacinia tellus, eget aliquet turpis mauris non enim. Nam turpis. Suspendisse lacinia. Curabitur ac tortor ut ipsum egestas elementum. Nunc imperdiet gravida mauris.</p>\r\n', 2, 0, 0, NULL, 'Program Studi Magister', 'Program Studi', 0, 1, 1, 0, NULL, '2016-08-18 00:00:00', 1, '2018-04-28 11:32:30', 1);
INSERT INTO `ad_project` (`project_id`, `lang_id`, `company_name`, `project_date`, `project_title`, `summary`, `content`, `type_id`, `cat_id`, `product_id`, `image`, `tags`, `page_title`, `read_count`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(19, 1, '', '0000-00-00', 'Riset 1', '', '<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas feugiat consequat diam. Maecenas metus. Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor. Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit. Nulla pretium mi et risus. Fusce mi pede, tempor id, cursus ac, ullamcorper nec, enim. Sed tortor. Curabitur molestie. Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum, est ut placerat elementum, lectus nisl aliquam velit, tempor aliquam eros nunc nonummy metus. In eros metus, gravida a, gravida sed, lobortis id, turpis. Ut ultrices, ipsum at venenatis fringilla, sem nulla lacinia tellus, eget aliquet turpis mauris non enim. Nam turpis. Suspendisse lacinia. Curabitur ac tortor ut ipsum egestas elementum. Nunc imperdiet gravida mauris.</p>\r\n', 2, 0, 0, NULL, '', '', 0, 1, 1, 0, NULL, '2017-04-06 00:00:00', 1, '2018-04-28 11:32:42', 1);
INSERT INTO `ad_project` (`project_id`, `lang_id`, `company_name`, `project_date`, `project_title`, `summary`, `content`, `type_id`, `cat_id`, `product_id`, `image`, `tags`, `page_title`, `read_count`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(23, 1, '', '0000-00-00', 'Sustainable Sciences', '', '<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas feugiat consequat diam. Maecenas metus. Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor. Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit. Nulla pretium mi et risus. Fusce mi pede, tempor id, cursus ac, ullamcorper nec, enim. Sed tortor. Curabitur molestie. Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum, est ut placerat elementum, lectus nisl aliquam velit, tempor aliquam eros nunc nonummy metus. In eros metus, gravida a, gravida sed, lobortis id, turpis. Ut ultrices, ipsum at venenatis fringilla, sem nulla lacinia tellus, eget aliquet turpis mauris non enim. Nam turpis. Suspendisse lacinia. Curabitur ac tortor ut ipsum egestas elementum. Nunc imperdiet gravida mauris.</p>\r\n', 2, 0, 0, NULL, 'Program Studi Magister', 'Program Studi', 0, 1, 1, 0, NULL, '2016-08-18 00:00:00', 1, '2018-04-28 11:32:55', 1);
INSERT INTO `ad_project` (`project_id`, `lang_id`, `company_name`, `project_date`, `project_title`, `summary`, `content`, `type_id`, `cat_id`, `product_id`, `image`, `tags`, `page_title`, `read_count`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(26, 1, '', NULL, 'testing satu edit', '', '<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Maecenas feugiat consequat diam. Maecenas metus. Vivamus diam purus, cursus a, commodo non, facilisis vitae, nulla. Aenean dictum lacinia tortor. Nunc iaculis, nibh non iaculis aliquam, orci felis euismod neque, sed ornare massa mauris sed velit. Nulla pretium mi et risus. Fusce mi pede, tempor id, cursus ac, ullamcorper nec, enim. Sed tortor. Curabitur molestie. Duis velit augue, condimentum at, ultrices a, luctus ut, orci. Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum, est ut placerat elementum, lectus nisl aliquam velit, tempor aliquam eros nunc nonummy metus. In eros metus, gravida a, gravida sed, lobortis id, turpis. Ut ultrices, ipsum at venenatis fringilla, sem nulla lacinia tellus, eget aliquet turpis mauris non enim. Nam turpis. Suspendisse lacinia. Curabitur ac tortor ut ipsum egestas elementum. Nunc imperdiet gravida mauris.</p>\n', 3, 0, 0, NULL, 'ngeteg,duwa', 'Tentang Kamisss', 0, 0, 0, 0, NULL, '2018-04-19 00:00:00', 1, '2018-04-21 22:02:34', 1);
INSERT INTO `ad_project` (`project_id`, `lang_id`, `company_name`, `project_date`, `project_title`, `summary`, `content`, `type_id`, `cat_id`, `product_id`, `image`, `tags`, `page_title`, `read_count`, `editor_approval`, `moderator_approval`, `is_published`, `publish_date`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(26, 2, '', NULL, 'Testing One edit', '', '<p><strong>EDIT </strong>Donec pellentesque egestas eros. Integer cursus, augue in cursus faucibus, eros pede bibendum sem, in tempus tellus justo quis ligula. Etiam eget tortor. Vestibulum rutrum, est ut placerat elementum, lectus nisl aliquam velit, tempor aliquam eros nunc nonummy metus. In eros metus, gravida a, gravida sed, lobortis id, turpis. Ut ultrices, ipsum at venenatis fringilla, sem nulla lacinia tellus, eget aliquet turpis mauris non enim. Nam turpis. Suspendisse lacinia. Curabitur ac tortor ut ipsum egestas elementum. Nunc imperdiet gravida mauris.</p>\n', 3, 0, 0, NULL, 'ngeteg,duwa', 'Page Titles', 0, 0, 0, 0, NULL, '2018-04-19 00:00:00', 1, '2018-04-22 00:50:01', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ad_role`
--

CREATE TABLE `ad_role` (
  `kode` int(3) NOT NULL,
  `nama_role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_role`
--

INSERT INTO `ad_role` (`kode`, `nama_role`) VALUES
(1, 'admin'),
(2, 'publisher'),
(3, 'moderator');
INSERT INTO `ad_role` (`kode`, `nama_role`) VALUES
(4, 'editor');

-- --------------------------------------------------------

--
-- Table structure for table `ad_role_menu`
--

CREATE TABLE `ad_role_menu` (
  `kode` int(4) NOT NULL,
  `menu` int(4) NOT NULL,
  `role` int(4) NOT NULL,
  `tambah` int(1) NOT NULL DEFAULT '0',
  `ubah` int(1) NOT NULL DEFAULT '0',
  `hapus` int(1) NOT NULL DEFAULT '0',
  `fitur` int(1) NOT NULL DEFAULT '0',
  `tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `oleh` int(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_role_menu`
--

INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(1, 1, 1, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(2, 2, 1, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(3, 3, 1, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(4, 4, 1, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(5, 5, 1, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(6, 6, 1, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(7, 7, 1, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(8, 8, 1, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(9, 9, 1, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(10, 10, 1, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(11, 11, 1, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(12, 12, 1, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(13, 13, 1, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(14, 14, 1, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(15, 15, 1, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(16, 16, 1, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(17, 17, 1, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(18, 18, 1, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(19, 19, 1, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(20, 20, 1, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(21, 21, 1, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(22, 1, 2, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(23, 2, 2, 0, 0, 0, 0, '2018-04-24 21:26:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(24, 1, 3, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(25, 1, 4, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(26, 22, 1, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);
INSERT INTO `ad_role_menu` (`kode`, `menu`, `role`, `tambah`, `ubah`, `hapus`, `fitur`, `tanggal`, `oleh`) VALUES
(27, 23, 1, 1, 1, 1, 1, '2018-04-24 21:20:55', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ad_runteks`
--

CREATE TABLE `ad_runteks` (
  `runteksid` int(11) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `content` text,
  `footer` varchar(50) DEFAULT NULL,
  `is_published` int(10) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `user_created` varchar(50) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `user_modified` varchar(50) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `ad_sitecounter`
--

CREATE TABLE `ad_sitecounter` (
  `counterid` int(10) NOT NULL,
  `reffid` int(10) DEFAULT NULL,
  `lang_id` int(10) NOT NULL DEFAULT '1',
  `url` text,
  `user_agent` char(125) CHARACTER SET utf8 DEFAULT NULL,
  `ip` char(20) CHARACTER SET utf8 DEFAULT NULL,
  `date_visit` datetime NOT NULL,
  `description` text,
  `counter` int(10) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_sitecounter`
--

INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(1, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(2, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(3, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(4, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(5, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(6, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(7, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(8, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(9, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(10, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(11, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(12, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(13, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(14, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(15, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(16, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(17, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(18, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(19, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(20, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(21, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(22, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(23, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(24, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(25, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(26, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(27, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(28, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(29, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(30, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(31, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(32, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(33, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(34, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(35, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(36, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(37, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(38, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(39, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(40, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(41, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(42, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(43, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(44, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(45, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(46, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(47, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(48, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(49, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(50, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(51, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(52, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(53, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(54, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(55, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(56, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(57, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(58, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(59, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(60, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(61, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(62, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(63, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(64, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(65, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(66, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(67, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(68, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(69, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(70, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(71, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(72, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(73, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(74, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(75, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(76, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(77, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(78, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(79, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(80, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(81, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(82, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(83, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(84, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(85, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(86, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(87, 4, 1, '/pascasarjana/artikel/4/Beasiswa', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(88, 3, 1, '/pascasarjana/artikel/3/Mahasiswa%20Penerima%20BPPDN%20DIKTI', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(89, 5, 1, '/pascasarjana/artikel/5/Implementasi%20Early%20Warning%20System', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(90, 6, 1, '/pascasarjana/artikel/6/Surat%20Edaran%20Dirjen%20Dikti', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(91, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(92, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(93, 4, 1, '/pascasarjana/artikel/4/Beasiswa', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(94, 4, 1, '/pascasarjana/artikel/4/Beasiswa', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(95, 4, 1, '/pascasarjana/artikel/4/Beasiswa', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(96, 4, 1, '/pascasarjana/artikel/4/Beasiswa', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(97, 4, 1, '/pascasarjana/artikel/4/Beasiswa', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(98, 4, 1, '/pascasarjana/artikel/4/Beasiswa', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(99, 4, 1, '/pascasarjana/artikel/4/Beasiswa', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(100, 3, 1, '/pascasarjana/artikel/3/Mahasiswa%20Penerima%20BPPDN%20DIKTI', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(101, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(102, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(103, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(104, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(105, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(106, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(107, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(108, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(109, 4, 1, '/pascasarjana/artikel/4/Beasiswa', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(110, 4, 1, '/pascasarjana/artikel/4/Beasiswa', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(111, 0, 1, '/pascasarjana/home', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(112, 0, 1, '/pascasarjana/home', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(113, 0, 1, '/pascasarjana/home', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(114, 6, 1, '/pascasarjana/artikel/6/Surat%20Edaran%20Dirjen%20Dikti', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(115, 0, 1, '/pascasarjana/home', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(116, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(117, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(118, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(119, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(120, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(121, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(122, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(123, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(124, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(125, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(126, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(127, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '127.0.0.1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(128, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '127.0.0.1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(129, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '127.0.0.1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(130, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '127.0.0.1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(131, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '127.0.0.1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(132, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '127.0.0.1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(133, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '127.0.0.1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(134, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '127.0.0.1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(135, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '127.0.0.1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(136, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '127.0.0.1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(137, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '127.0.0.1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(138, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '127.0.0.1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(139, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '127.0.0.1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(140, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '127.0.0.1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(141, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '127.0.0.1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(142, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '127.0.0.1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(143, 0, 1, '/pascasarjana/', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', '127.0.0.1', '0000-00-00 00:00:00', 'home', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(144, 1, 1, '/pascasarjana/artikel/1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/601.7.7 (KHTML, like Gecko) Version/9.1.2 Safari/601.7.7', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(145, 1, 1, '/pascasarjana/artikel/1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/601.7.7 (KHTML, like Gecko) Version/9.1.2 Safari/601.7.7', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(146, 1, 1, '/pascasarjana/artikel/1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/601.7.7 (KHTML, like Gecko) Version/9.1.2 Safari/601.7.7', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(147, 1, 1, '/pascasarjana/artikel/1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/601.7.7 (KHTML, like Gecko) Version/9.1.2 Safari/601.7.7', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(148, 1, 1, '/pascasarjana/artikel/1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/601.7.7 (KHTML, like Gecko) Version/9.1.2 Safari/601.7.7', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(149, 12, 1, '/pascasarjana/artikel/12', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/601.7.7 (KHTML, like Gecko) Version/9.1.2 Safari/601.7.7', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(150, 12, 1, '/pascasarjana/artikel/12', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/601.7.7 (KHTML, like Gecko) Version/9.1.2 Safari/601.7.7', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(151, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(152, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(153, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(154, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(155, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(156, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(157, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(158, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(159, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(160, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(161, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(162, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(163, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(164, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(165, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(166, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(167, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(168, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(169, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(170, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(171, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(172, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(173, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(174, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(175, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(176, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(177, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(178, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(179, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(180, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(181, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(182, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(183, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(184, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(185, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(186, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(187, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(188, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(189, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(190, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(191, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(192, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(193, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(194, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(195, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(196, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(197, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(198, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(199, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(200, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(201, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(202, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(203, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(204, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(205, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(206, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(207, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(208, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(209, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(210, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(211, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(212, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(213, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(214, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(215, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(216, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(217, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(218, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(219, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(220, 4, 1, '/pascasarjana/warta/4/surat-edaran-dirjen-dikti', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(221, 4, 1, '/pascasarjana/warta/4/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(222, 4, 1, '/pascasarjana/warta/4/surat-edaran-dirjen-dikti', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(223, 4, 1, '/pascasarjana/warta/4/surat-edaran-dirjen-dikti', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(224, 4, 1, '/pascasarjana/warta/4/surat-edaran-dirjen-dikti', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(225, 4, 1, '/pascasarjana/warta/4/surat-edaran-dirjen-dikti', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(226, 4, 1, '/pascasarjana/warta/4/surat-edaran-dirjen-dikti', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(227, 4, 1, '/pascasarjana/warta/4/surat-edaran-dirjen-dikti', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(228, 4, 1, '/pascasarjana/warta/4/surat-edaran-dirjen-dikti', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(229, 4, 1, '/pascasarjana/warta/4/surat-edaran-dirjen-dikti', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(230, 4, 1, '/pascasarjana/warta/4/surat-edaran-dirjen-dikti', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(231, 4, 1, '/pascasarjana/warta/4/surat-edaran-dirjen-dikti', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(232, 3, 1, '/pascasarjana/warta/3/implementasi-early-warning-system', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(233, 3, 1, '/pascasarjana/warta/3/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(234, 5, 1, '/pascasarjana/warta/5/perpanjangan-studi-program-doktor-angkatan-tahun-2013-semester-ke-8', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(235, 5, 1, '/pascasarjana/warta/5/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(236, 2, 1, '/pascasarjana/warta/2/beasiswa', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(237, 2, 1, '/pascasarjana/warta/2/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(238, 5, 1, '/pascasarjana/warta/5/perpanjangan-studi-program-doktor-angkatan-tahun-2013-semester-ke-8', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(239, 2, 1, '/pascasarjana/warta/2/beasiswa', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(240, 2, 1, '/pascasarjana/warta/2/beasiswa', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(241, 2, 1, '/pascasarjana/warta/2/beasiswa', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(242, 5, 1, '/pascasarjana/warta/5/perpanjangan-studi-program-doktor-angkatan-tahun-2013-semester-ke-8', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(243, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(244, 4, 1, '/pascasarjana/warta/4/surat-edaran-dirjen-dikti', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(245, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(246, 8, 1, '/pascasarjana/artikel/8/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(247, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(248, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(249, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(250, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(251, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(252, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(253, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(254, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(255, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(256, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(257, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(258, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(259, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(260, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(261, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(262, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(263, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(264, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(265, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(266, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(267, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(268, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(269, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(270, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(271, 4, 1, '/pascasarjana/warta/4/surat-edaran-dirjen-dikti', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(272, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(273, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(274, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(275, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(276, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(277, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(278, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(279, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(280, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(281, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(282, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(283, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(284, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(285, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(286, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(287, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(288, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(289, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(290, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(291, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(292, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(293, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(294, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(295, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(296, 15, 1, '/pascasarjana/artikel/15/magister-pariwisata-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(297, 15, 1, '/pascasarjana/artikel/15/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(298, 17, 1, '/pascasarjana/artikel/17/magister-manajemen-sumberdaya-hayati', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(299, 17, 1, '/pascasarjana/artikel/17/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(300, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(301, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(302, 4, 1, '/pascasarjana/warta/4', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(303, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(304, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(305, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(306, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(307, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(308, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(309, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(310, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(311, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(312, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(313, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(314, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(315, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(316, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(317, 12, 1, '/pascasarjana/artikel/12/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(318, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(319, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(320, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(321, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(322, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(323, 11, 1, '/pascasarjana/artikel/11/doktor-ilmu-lingkungan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(324, 11, 1, '/pascasarjana/artikel/11/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(325, 18, 1, '/pascasarjana/artikel/18/magister-ilmu-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(326, 18, 1, '/pascasarjana/artikel/18/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(327, 11, 1, '/pascasarjana/artikel/11/doktor-ilmu-lingkungan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(328, 14, 1, '/pascasarjana/artikel/14/magister-ilmu-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(329, 14, 1, '/pascasarjana/artikel/14/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(330, 16, 1, '/pascasarjana/artikel/16/magister-inovasi-regional', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(331, 16, 1, '/pascasarjana/artikel/16/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(332, 17, 1, '/pascasarjana/artikel/17/magister-manajemen-sumberdaya-hayati', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(333, 15, 1, '/pascasarjana/artikel/15/magister-pariwisata-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(334, 15, 1, '/pascasarjana/artikel/15/magister-pariwisata-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(335, 11, 1, '/pascasarjana/artikel/11/doktor-ilmu-lingkungan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(336, 14, 1, '/pascasarjana/artikel/14/magister-ilmu-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(337, 16, 1, '/pascasarjana/artikel/16/magister-inovasi-regional', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(338, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(339, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(340, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(341, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(342, 7, 1, '/pascasarjana/artikel/7/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(343, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(344, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(345, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(346, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(347, 2, 1, '/pascasarjana/artikel/2/struktur-organisasi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(348, 2, 1, '/pascasarjana/artikel/2/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(349, 11, 1, '/pascasarjana/artikel/11/doktor-ilmu-lingkungan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(350, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(351, 8, 1, '/pascasarjana/artikel/8/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(352, 1, 1, '/pascasarjana/artikel/1/informasi-umum', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(353, 1, 1, '/pascasarjana/artikel/1/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(354, 2, 1, '/pascasarjana/artikel/2/struktur-organisasi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(355, 2, 1, '/pascasarjana/artikel/2/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(356, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(357, 12, 1, '/pascasarjana/artikel/12/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(358, 1, 1, '/pascasarjana/artikel/1/informasi-umum', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(359, 2, 1, '/pascasarjana/artikel/2/struktur-organisasi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(360, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(361, 2, 1, '/pascasarjana/artikel/2/struktur-organisasi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(362, 2, 1, '/pascasarjana/artikel/2/struktur-organisasi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(363, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(364, 2, 1, '/pascasarjana/artikel/2/struktur-organisasi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(365, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(366, 18, 1, '/pascasarjana/artikel/18/magister-ilmu-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(367, 18, 1, '/pascasarjana/artikel/18/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(368, 14, 1, '/pascasarjana/artikel/14/magister-ilmu-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(369, 14, 1, '/pascasarjana/artikel/14/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(370, 13, 1, '/pascasarjana/artikel/13/magister-ilmu-lingkungan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(371, 13, 1, '/pascasarjana/artikel/13/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(372, 16, 1, '/pascasarjana/artikel/16/magister-inovasi-regional', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(373, 16, 1, '/pascasarjana/artikel/16/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(374, 1, 1, '/pascasarjana/artikel/1/informasi-umum', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(375, 1, 1, '/pascasarjana/artikel/1/informasi-umum', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(376, 1, 1, '/pascasarjana/artikel/1/informasi-umum', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(377, 1, 1, '/pascasarjana/artikel/1/informasi-umum', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(378, 1, 1, '/pascasarjana/artikel/1/informasi-umum', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(379, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(380, 13, 1, '/pascasarjana/artikel/13/magister-ilmu-lingkungan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(381, 15, 1, '/pascasarjana/artikel/15/magister-pariwisata-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(382, 15, 1, '/pascasarjana/artikel/15/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(383, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(384, 7, 1, '/pascasarjana/artikel/7/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(385, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(386, 1, 1, '/pascasarjana/artikel/1/informasi-umum', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(387, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(388, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(389, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(390, 11, 1, '/pascasarjana/artikel/11/doktor-ilmu-lingkungan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(391, 11, 1, '/pascasarjana/artikel/11/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(392, 11, 1, '/pascasarjana/artikel/11/doktor-ilmu-lingkungan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(393, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(394, 18, 1, '/pascasarjana/artikel/18/magister-ilmu-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(395, 13, 1, '/pascasarjana/artikel/13/magister-ilmu-lingkungan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(396, 17, 1, '/pascasarjana/artikel/17/magister-manajemen-sumberdaya-hayati', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(397, 17, 1, '/pascasarjana/artikel/17/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(398, 15, 1, '/pascasarjana/artikel/15/magister-pariwisata-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(399, 15, 1, '/pascasarjana/artikel/15/magister-pariwisata-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(400, 15, 1, '/pascasarjana/artikel/15/magister-pariwisata-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(401, 11, 1, '/pascasarjana/artikel/11/doktor-ilmu-lingkungan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(402, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(403, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(404, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(405, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(406, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(407, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(408, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(409, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(410, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(411, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(412, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(413, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(414, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(415, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(416, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(417, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(418, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(419, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(420, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(421, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(422, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(423, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(424, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(425, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(426, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(427, 1, 1, '/pascasarjana/artikel/1/informasi-umum', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(428, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(429, 1, 1, '/pascasarjana/artikel/1/informasi-umum', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(430, 1, 1, '/pascasarjana/artikel/1/informasi-umum', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(431, 1, 1, '/pascasarjana/artikel/1/informasi-umum', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(432, 1, 1, '/pascasarjana/artikel/1/informasi-umum', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(433, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(434, 1, 1, '/pascasarjana/artikel/1/informasi-umum', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(435, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(436, 18, 1, '/pascasarjana/artikel/18/magister-ilmu-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(437, 18, 1, '/pascasarjana/artikel/18/magister-ilmu-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(438, 18, 1, '/pascasarjana/artikel/18/magister-ilmu-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(439, 18, 1, '/pascasarjana/artikel/18/magister-ilmu-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(440, 18, 1, '/pascasarjana/artikel/18/magister-ilmu-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(441, 18, 1, '/pascasarjana/artikel/18/magister-ilmu-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(442, 18, 1, '/pascasarjana/artikel/18/magister-ilmu-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(443, 18, 1, '/pascasarjana/artikel/18/magister-ilmu-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(444, 18, 1, '/pascasarjana/artikel/18/magister-ilmu-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(445, 18, 1, '/pascasarjana/artikel/18/magister-ilmu-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(446, 18, 1, '/pascasarjana/artikel/18/magister-ilmu-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(447, 18, 1, '/pascasarjana/artikel/18/magister-ilmu-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(448, 18, 1, '/pascasarjana/artikel/18/magister-ilmu-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(449, 18, 1, '/pascasarjana/artikel/18/magister-ilmu-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(450, 18, 1, '/pascasarjana/artikel/18/magister-ilmu-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(451, 18, 1, '/pascasarjana/artikel/18/magister-ilmu-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(452, 18, 1, '/pascasarjana/artikel/18/magister-ilmu-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(453, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(454, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(455, 4, 1, '/pascasarjana/warta/4/surat-edaran-dirjen-dikti', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(456, 4, 1, '/pascasarjana/warta/4/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(457, 3, 1, '/pascasarjana/warta/3/implementasi-early-warning-system', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(458, 3, 1, '/pascasarjana/warta/3/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(459, 11, 1, '/pascasarjana/artikel/11/doktor-ilmu-lingkungan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(460, 14, 1, '/pascasarjana/artikel/14/magister-ilmu-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(461, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(462, 1, 1, '/pascasarjana/artikel/1/informasi-umum', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(463, 2, 1, '/pascasarjana/artikel/2/struktur-organisasi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(464, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(465, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(466, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(467, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(468, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(469, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(470, 2, 1, '/pascasarjana/artikel/2/struktur-organisasi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(471, 15, 1, '/pascasarjana/artikel/15/magister-pariwisata-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(472, 4, 1, '/pascasarjana/warta/4', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(473, 5, 1, '/pascasarjana/warta/5/perpanjangan-studi-program-doktor-angkatan-tahun-2013-semester-ke-8', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(474, 5, 1, '/pascasarjana/warta/5/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(475, 2, 1, '/pascasarjana/warta/2/beasiswa', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(476, 2, 1, '/pascasarjana/warta/2/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(477, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(478, 5, 1, '/pascasarjana/warta/5', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(479, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(480, 11, 1, '/pascasarjana/artikel/11/doktor-ilmu-lingkungan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(481, 11, 1, '/pascasarjana/artikel/11/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(482, 11, 1, '/pascasarjana/artikel/11/doktor-ilmu-lingkungan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(483, 18, 1, '/pascasarjana/artikel/18/magister-ilmu-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(484, 18, 1, '/pascasarjana/artikel/18/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(485, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(486, 8, 1, '/pascasarjana/artikel/8/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(487, 6, 1, '/pascasarjana/warta/6', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(488, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(489, 12, 1, '/pascasarjana/artikel/12/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(490, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(491, 11, 1, '/pascasarjana/artikel/11/doktor-ilmu-lingkungan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(492, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(493, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(494, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(495, 11, 1, '/pascasarjana/artikel/11/doktor-ilmu-lingkungan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(496, 11, 1, '/pascasarjana/artikel/11', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(497, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(498, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(499, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(500, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(501, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(502, 13, 1, '/pascasarjana/artikel/13/magister-ilmu-lingkungan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(503, 13, 1, '/pascasarjana/artikel/13/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(504, 1, 1, '/pascasarjana/artikel/1/informasi-umum', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(505, 1, 1, '/pascasarjana/artikel/1/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(506, 2, 1, '/pascasarjana/artikel/2/struktur-organisasi', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(507, 2, 1, '/pascasarjana/artikel/2/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(508, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(509, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(510, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(511, 7, 1, '/pascasarjana/artikel/7/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(512, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(513, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Windows NT 6.1; rv:51.0) Gecko/20100101 Firefox/51.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(514, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(515, 8, 1, '/pascasarjana/artikel/8/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(516, 11, 1, '/pascasarjana/artikel/11/doktor-ilmu-lingkungan', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(517, 11, 1, '/pascasarjana/artikel/11/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(518, 14, 1, '/pascasarjana/artikel/14/magister-ilmu-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(519, 14, 1, '/pascasarjana/artikel/14/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(520, 16, 1, '/pascasarjana/artikel/16/magister-inovasi-regional', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(521, 16, 1, '/pascasarjana/artikel/16/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(522, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(523, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(524, 7, 1, '/pascasarjana/artikel/7/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(525, 2, 1, '/pascasarjana/artikel/2/struktur-organisasi', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(526, 2, 1, '/pascasarjana/artikel/2/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(527, 6, 1, '/pascasarjana/warta/6', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(528, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(529, 8, 1, '/pascasarjana/artikel/8/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(530, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(531, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(532, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(533, 7, 1, '/pascasarjana/warta/7', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(534, 7, 1, '/pascasarjana/warta/7', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(535, 5, 1, '/pascasarjana/warta/5/perpanjangan-studi-program-doktor-angkatan-tahun-2013-semester-ke-8', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(536, 5, 1, '/pascasarjana/warta/5/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(537, 7, 1, '/pascasarjana/warta/7', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(538, 6, 1, '/pascasarjana/warta/6/studi-di-ilmu-liingkungan-unpad-s2-dan-s3-by-research-dengan-beasiswa-unggulan', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(539, 6, 1, '/pascasarjana/warta/6/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(540, 5, 1, '/pascasarjana/warta/5/perpanjangan-studi-program-doktor-angkatan-tahun-2013-semester-ke-8', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(541, 7, 1, '/pascasarjana/warta/7', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(542, 7, 1, '/pascasarjana/warta/7', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(543, 7, 1, '/pascasarjana/warta/7', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(544, 7, 1, '/pascasarjana/warta/7', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(545, 7, 1, '/pascasarjana/warta/7', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(546, 6, 1, '/pascasarjana/warta/6/studi-di-ilmu-liingkungan-unpad-s2-dan-s3-by-research-dengan-beasiswa-unggulan', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(547, 4, 1, '/pascasarjana/warta/4/surat-edaran-dirjen-dikti', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(548, 4, 1, '/pascasarjana/warta/4/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(549, 7, 1, '/pascasarjana/warta/7', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(550, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(551, 12, 1, '/pascasarjana/artikel/12/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(552, 18, 1, '/pascasarjana/artikel/18/magister-ilmu-berkelanjutan', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(553, 18, 1, '/pascasarjana/artikel/18/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(554, 11, 1, '/pascasarjana/artikel/11/doktor-ilmu-lingkungan', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(555, 11, 1, '/pascasarjana/artikel/11/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(556, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(557, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(558, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(559, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(560, 7, 1, '/pascasarjana/artikel/7/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(561, 2, 1, '/pascasarjana/artikel/2/struktur-organisasi', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(562, 2, 1, '/pascasarjana/artikel/2/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(563, 7, 1, '/pascasarjana/warta/7', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(564, 7, 1, '/pascasarjana/warta/7', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(565, 7, 1, '/pascasarjana/warta/7', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(566, 7, 1, '/pascasarjana/warta/7', 'Mozilla/5.0 (Windows NT 6.1; rv:52.0) Gecko/20100101 Firefox/52.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(567, 8, 1, '/pascasarjana/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:53.0) Gecko/20100101 Firefox/53.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(568, 8, 1, '/pascasarjana/artikel/8/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:53.0) Gecko/20100101 Firefox/53.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(569, 12, 1, '/pascasarjana/artikel/12/doktor-bioteknologi', 'Mozilla/5.0 (Windows NT 6.1; rv:53.0) Gecko/20100101 Firefox/53.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(570, 12, 1, '/pascasarjana/artikel/12/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:53.0) Gecko/20100101 Firefox/53.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(571, 7, 1, '/pascasarjana/artikel/7/sejarah', 'Mozilla/5.0 (Windows NT 6.1; rv:53.0) Gecko/20100101 Firefox/53.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(572, 7, 1, '/pascasarjana/artikel/7/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:53.0) Gecko/20100101 Firefox/53.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(573, 6, 1, '/pascasarjana/warta/6', 'Mozilla/5.0 (Windows NT 6.1; rv:53.0) Gecko/20100101 Firefox/53.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(574, 7, 1, '/pascasarjana/warta/7', 'Mozilla/5.0 (Windows NT 6.1; rv:53.0) Gecko/20100101 Firefox/53.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(575, 7, 1, '/pascasarjana/warta/7', 'Mozilla/5.0 (Windows NT 6.1; rv:53.0) Gecko/20100101 Firefox/53.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(576, 8, 1, '/newpasca/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(577, 8, 1, '/newpasca/artikel/8/apple-touch-icon-144x144-precomposed.png', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(578, 8, 1, '/newpasca/artikel/8/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(579, 8, 1, '/newpasca/artikel/8/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(580, 8, 1, '/newpasca/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(581, NULL, 1, '/newpasca/id/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(582, NULL, 1, '/newpasca/id/artikel/8/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(583, NULL, 1, '/newpasca/id/artikel/8/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(584, NULL, 1, '/newpasca/id/artikel/8/apple-touch-icon-144x144-precomposed.png', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(585, NULL, 1, '/newpasca/id/artikel/8/visi-misi-dan-tujuan', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', '::1', '0000-00-00 00:00:00', 'artikel', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(586, 6, 1, '/newpasca/id/warta/36/studi-di-ilmu-liingkungan-unpad-s2-dan-s3-by-research-dengan-beasiswa-unggulan', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(587, 6, 1, '/newpasca/id/warta/36/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(588, 6, 1, '/newpasca/id/warta/36/apple-touch-icon-144x144-precomposed.png', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', '::1', '0000-00-00 00:00:00', 'news', 1);
INSERT INTO `ad_sitecounter` (`counterid`, `reffid`, `lang_id`, `url`, `user_agent`, `ip`, `date_visit`, `description`, `counter`) VALUES
(589, 6, 1, '/newpasca/id/warta/36/favicon.ico', 'Mozilla/5.0 (Windows NT 6.1; rv:59.0) Gecko/20100101 Firefox/59.0', '::1', '0000-00-00 00:00:00', 'news', 1);

-- --------------------------------------------------------

--
-- Table structure for table `ad_slider`
--

CREATE TABLE `ad_slider` (
  `slider_id` int(4) NOT NULL,
  `article_id` int(6) DEFAULT NULL,
  `cat_id` int(4) DEFAULT NULL,
  `type_id` int(2) DEFAULT NULL,
  `lang_id` tinyint(2) DEFAULT NULL,
  `slider_text` text,
  `description` text,
  `image` text,
  `imagepos` varchar(10) NOT NULL DEFAULT 'center',
  `editor_approval` tinyint(1) NOT NULL DEFAULT '0',
  `moderator_approval` tinyint(1) NOT NULL DEFAULT '0',
  `is_published` tinyint(1) DEFAULT '0',
  `published_date` datetime DEFAULT NULL,
  `urutan` int(2) NOT NULL DEFAULT '0',
  `active` tinyint(3) NOT NULL DEFAULT '0',
  `user_created` int(4) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_modified` int(4) DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_slider`
--

INSERT INTO `ad_slider` (`slider_id`, `article_id`, `cat_id`, `type_id`, `lang_id`, `slider_text`, `description`, `image`, `imagepos`, `editor_approval`, `moderator_approval`, `is_published`, `published_date`, `urutan`, `active`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES
(8, NULL, NULL, NULL, NULL, 'T4', '', 't4.png', 'center', 1, 1, 1, '2017-04-20 00:00:00', 3, 1, 0, '2016-08-19 00:00:00', 1, '2021-09-17 10:44:36');
INSERT INTO `ad_slider` (`slider_id`, `article_id`, `cat_id`, `type_id`, `lang_id`, `slider_text`, `description`, `image`, `imagepos`, `editor_approval`, `moderator_approval`, `is_published`, `published_date`, `urutan`, `active`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES
(19, NULL, NULL, NULL, NULL, 'Banner 2', '', 'banner1-3.png', 'right', 1, 1, 1, '2021-09-17 00:00:00', 10, 1, 1, '2021-09-17 00:00:00', NULL, NULL);
INSERT INTO `ad_slider` (`slider_id`, `article_id`, `cat_id`, `type_id`, `lang_id`, `slider_text`, `description`, `image`, `imagepos`, `editor_approval`, `moderator_approval`, `is_published`, `published_date`, `urutan`, `active`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES
(20, NULL, NULL, NULL, NULL, 'Banner 3', '', 'banner1-1.png', 'right', 1, 1, 1, '2021-09-17 00:00:00', 11, 1, 1, '2021-09-17 00:00:00', NULL, NULL);
INSERT INTO `ad_slider` (`slider_id`, `article_id`, `cat_id`, `type_id`, `lang_id`, `slider_text`, `description`, `image`, `imagepos`, `editor_approval`, `moderator_approval`, `is_published`, `published_date`, `urutan`, `active`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES
(9, NULL, NULL, NULL, NULL, 'T6', '', 't6.png', 'center', 1, 1, 1, '2018-04-25 00:00:00', 4, 1, 0, '2016-08-20 00:00:00', 1, '2021-09-17 10:44:25');
INSERT INTO `ad_slider` (`slider_id`, `article_id`, `cat_id`, `type_id`, `lang_id`, `slider_text`, `description`, `image`, `imagepos`, `editor_approval`, `moderator_approval`, `is_published`, `published_date`, `urutan`, `active`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES
(17, NULL, NULL, NULL, NULL, 'Top left', '', 'top-left.png', 'center', 1, 1, 1, '2021-09-17 00:00:00', 8, 1, 1, '2021-09-17 00:00:00', NULL, NULL);
INSERT INTO `ad_slider` (`slider_id`, `article_id`, `cat_id`, `type_id`, `lang_id`, `slider_text`, `description`, `image`, `imagepos`, `editor_approval`, `moderator_approval`, `is_published`, `published_date`, `urutan`, `active`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES
(18, NULL, NULL, NULL, NULL, 'Banner 1', '', 'banner1-2.png', 'right', 1, 1, 1, '2021-09-17 00:00:00', 9, 1, 1, '2021-09-17 00:00:00', NULL, NULL);
INSERT INTO `ad_slider` (`slider_id`, `article_id`, `cat_id`, `type_id`, `lang_id`, `slider_text`, `description`, `image`, `imagepos`, `editor_approval`, `moderator_approval`, `is_published`, `published_date`, `urutan`, `active`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES
(7, NULL, NULL, NULL, NULL, 'Tera', '', 'tera.png', 'center', 1, 1, 1, '2017-04-20 00:00:00', 5, 1, 0, '2016-08-19 00:00:00', 1, '2021-09-17 10:44:48');
INSERT INTO `ad_slider` (`slider_id`, `article_id`, `cat_id`, `type_id`, `lang_id`, `slider_text`, `description`, `image`, `imagepos`, `editor_approval`, `moderator_approval`, `is_published`, `published_date`, `urutan`, `active`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES
(15, NULL, NULL, NULL, NULL, 'T7', '', 't7.png', 'center', 1, 1, 1, '2021-09-17 00:00:00', 6, 1, 1, '2021-09-17 00:00:00', NULL, NULL);
INSERT INTO `ad_slider` (`slider_id`, `article_id`, `cat_id`, `type_id`, `lang_id`, `slider_text`, `description`, `image`, `imagepos`, `editor_approval`, `moderator_approval`, `is_published`, `published_date`, `urutan`, `active`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES
(16, NULL, NULL, NULL, NULL, 'Tri2', '', 'tri2.png', 'center', 1, 1, 1, '2021-09-17 00:00:00', 7, 1, 1, '2021-09-17 00:00:00', NULL, NULL);
INSERT INTO `ad_slider` (`slider_id`, `article_id`, `cat_id`, `type_id`, `lang_id`, `slider_text`, `description`, `image`, `imagepos`, `editor_approval`, `moderator_approval`, `is_published`, `published_date`, `urutan`, `active`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES
(13, NULL, NULL, NULL, NULL, 'T1', '', 't1.png', 'center', 1, 1, 1, '2021-09-17 00:00:00', 1, 1, 1, '2018-04-17 00:00:00', 1, '2021-09-17 10:44:16');
INSERT INTO `ad_slider` (`slider_id`, `article_id`, `cat_id`, `type_id`, `lang_id`, `slider_text`, `description`, `image`, `imagepos`, `editor_approval`, `moderator_approval`, `is_published`, `published_date`, `urutan`, `active`, `user_created`, `date_created`, `user_modified`, `date_modified`) VALUES
(14, NULL, NULL, NULL, NULL, 'T5', '', 't5.png', 'center', 1, 1, 1, NULL, 2, 1, 1, '2018-04-24 00:00:00', 1, '2021-09-17 10:44:02');

-- --------------------------------------------------------

--
-- Table structure for table `ad_status`
--

CREATE TABLE `ad_status` (
  `status_id` int(10) NOT NULL,
  `status` int(10) NOT NULL DEFAULT '0',
  `status_name` char(50) CHARACTER SET utf8 DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_status`
--

INSERT INTO `ad_status` (`status_id`, `status`, `status_name`) VALUES
(1, 0, 'New Article');
INSERT INTO `ad_status` (`status_id`, `status`, `status_name`) VALUES
(2, 1, 'Editor Approved');
INSERT INTO `ad_status` (`status_id`, `status`, `status_name`) VALUES
(3, 2, 'Moderator Approved / Unpublished');
INSERT INTO `ad_status` (`status_id`, `status`, `status_name`) VALUES
(4, 3, 'Published');

-- --------------------------------------------------------

--
-- Table structure for table `ad_type`
--

CREATE TABLE `ad_type` (
  `type_id` int(2) NOT NULL,
  `type_name` char(25) CHARACTER SET utf8 NOT NULL,
  `type_grp` char(15) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_type`
--

INSERT INTO `ad_type` (`type_id`, `type_name`, `type_grp`) VALUES
(1, '-', 'article');
INSERT INTO `ad_type` (`type_id`, `type_name`, `type_grp`) VALUES
(2, 'Article', 'article');
INSERT INTO `ad_type` (`type_id`, `type_name`, `type_grp`) VALUES
(3, 'Content', 'article');
INSERT INTO `ad_type` (`type_id`, `type_name`, `type_grp`) VALUES
(4, 'Module', 'article');
INSERT INTO `ad_type` (`type_id`, `type_name`, `type_grp`) VALUES
(5, '-', 'news');
INSERT INTO `ad_type` (`type_id`, `type_name`, `type_grp`) VALUES
(6, 'News', 'news');
INSERT INTO `ad_type` (`type_id`, `type_name`, `type_grp`) VALUES
(7, 'Informasi', 'news');
INSERT INTO `ad_type` (`type_id`, `type_name`, `type_grp`) VALUES
(8, 'Module', 'news');
INSERT INTO `ad_type` (`type_id`, `type_name`, `type_grp`) VALUES
(9, 'Beasiswa', 'news');
INSERT INTO `ad_type` (`type_id`, `type_name`, `type_grp`) VALUES
(10, 'Feature', 'article');
INSERT INTO `ad_type` (`type_id`, `type_name`, `type_grp`) VALUES
(11, 'Project', 'article');
INSERT INTO `ad_type` (`type_id`, `type_name`, `type_grp`) VALUES
(12, 'Glosika', 'project');
INSERT INTO `ad_type` (`type_id`, `type_name`, `type_grp`) VALUES
(13, 'Geska', 'project');
INSERT INTO `ad_type` (`type_id`, `type_name`, `type_grp`) VALUES
(14, 'Glomark', 'project');
INSERT INTO `ad_type` (`type_id`, `type_name`, `type_grp`) VALUES
(15, 'Product', 'service');
INSERT INTO `ad_type` (`type_id`, `type_name`, `type_grp`) VALUES
(16, 'Services', 'service');

-- --------------------------------------------------------

--
-- Table structure for table `ad_user`
--

CREATE TABLE `ad_user` (
  `user_id` int(4) NOT NULL,
  `username` varchar(100) NOT NULL,
  `first_name` char(25) CHARACTER SET utf8 DEFAULT NULL,
  `last_name` char(25) CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role_id` int(3) NOT NULL,
  `image` text,
  `isActive` tinyint(1) NOT NULL DEFAULT '0',
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_created` int(4) NOT NULL,
  `date_modified` datetime NOT NULL,
  `user_modified` int(4) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ad_user`
--

INSERT INTO `ad_user` (`user_id`, `username`, `first_name`, `last_name`, `email`, `password`, `role_id`, `image`, `isActive`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(1, 'aep darmawan', 'aep', 'darmawan', 'aep.darmawan@gmail.com', '0192023a7bbd73250516f069df18b500', 1, 'shiluet-01.png', 1, '2014-02-15 00:00:00', 0, '0000-00-00 00:00:00', NULL);
INSERT INTO `ad_user` (`user_id`, `username`, `first_name`, `last_name`, `email`, `password`, `role_id`, `image`, `isActive`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(2, 'adminweb', 'Publisher', 'Web', 'publisher@website', 'd41d8cd98f00b204e9800998ecf8427e', 2, 'priajpg.jpeg', 1, '2014-02-15 00:00:00', 0, '2018-04-24 06:31:33', 1);
INSERT INTO `ad_user` (`user_id`, `username`, `first_name`, `last_name`, `email`, `password`, `role_id`, `image`, `isActive`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(3, 'dickyichsan', 'Moderator', 'Web', 'moderator@website', 'd41d8cd98f00b204e9800998ecf8427e', 3, 'wanitajpg.jpeg', 1, '2017-04-11 02:23:57', 0, '2018-04-24 06:32:10', 1);
INSERT INTO `ad_user` (`user_id`, `username`, `first_name`, `last_name`, `email`, `password`, `role_id`, `image`, `isActive`, `date_created`, `user_created`, `date_modified`, `user_modified`) VALUES
(4, '', 'Editor', 'Web', 'editor@website', 'd9ac1ddc743663ed6687e77a5c01ee7d', 4, 'profile-imgjpg.jpeg', 1, '2018-04-24 11:36:12', 1, '2018-04-24 06:36:43', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ad_agenda`
--
ALTER TABLE `ad_agenda`
  ADD PRIMARY KEY (`agenda_id`);

--
-- Indexes for table `ad_artikel`
--
ALTER TABLE `ad_artikel`
  ADD PRIMARY KEY (`article_id`,`lang_id`);
ALTER TABLE `ad_artikel` ADD FULLTEXT KEY `article_title` (`article_title`,`content`);

--
-- Indexes for table `ad_berita`
--
ALTER TABLE `ad_berita`
  ADD PRIMARY KEY (`news_id`,`lang_id`);
ALTER TABLE `ad_berita` ADD FULLTEXT KEY `news_title` (`news_title`,`content`);

--
-- Indexes for table `ad_event`
--
ALTER TABLE `ad_event`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `ad_galeri`
--
ALTER TABLE `ad_galeri`
  ADD PRIMARY KEY (`galeri_id`);

--
-- Indexes for table `ad_image`
--
ALTER TABLE `ad_image`
  ADD PRIMARY KEY (`image_id`);

--
-- Indexes for table `ad_kategori_agenda`
--
ALTER TABLE `ad_kategori_agenda`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `ad_kategori_artikel`
--
ALTER TABLE `ad_kategori_artikel`
  ADD PRIMARY KEY (`tbl_id`),
  ADD UNIQUE KEY `UNQKEY1` (`name`,`article_id`);

--
-- Indexes for table `ad_kategori_galeri`
--
ALTER TABLE `ad_kategori_galeri`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `ad_kategori_product`
--
ALTER TABLE `ad_kategori_product`
  ADD PRIMARY KEY (`cat_id`),
  ADD UNIQUE KEY `UNQKATPR` (`name`);

--
-- Indexes for table `ad_kategori_project`
--
ALTER TABLE `ad_kategori_project`
  ADD PRIMARY KEY (`tbl_id`);

--
-- Indexes for table `ad_komentar`
--
ALTER TABLE `ad_komentar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ad_konfigurasi`
--
ALTER TABLE `ad_konfigurasi`
  ADD PRIMARY KEY (`kode`),
  ADD UNIQUE KEY `UNQKEY` (`kunci`),
  ADD KEY `IDXTBL` (`urutan`);

--
-- Indexes for table `ad_log`
--
ALTER TABLE `ad_log`
  ADD PRIMARY KEY (`logid`),
  ADD KEY `logdate` (`logdate`);

--
-- Indexes for table `ad_menu`
--
ALTER TABLE `ad_menu`
  ADD PRIMARY KEY (`menu_id`);

--
-- Indexes for table `ad_menu_admin`
--
ALTER TABLE `ad_menu_admin`
  ADD PRIMARY KEY (`kode`);

--
-- Indexes for table `ad_menu_role`
--
ALTER TABLE `ad_menu_role`
  ADD PRIMARY KEY (`kode`);

--
-- Indexes for table `ad_polls`
--
ALTER TABLE `ad_polls`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ad_poll_votes`
--
ALTER TABLE `ad_poll_votes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ad_product`
--
ALTER TABLE `ad_product`
  ADD PRIMARY KEY (`product_id`,`lang_id`);
ALTER TABLE `ad_product` ADD FULLTEXT KEY `article_title` (`product_title`,`content`);

--
-- Indexes for table `ad_profil`
--
ALTER TABLE `ad_profil`
  ADD PRIMARY KEY (`kode`);

--
-- Indexes for table `ad_project`
--
ALTER TABLE `ad_project`
  ADD PRIMARY KEY (`project_id`,`lang_id`);
ALTER TABLE `ad_project` ADD FULLTEXT KEY `article_title` (`project_title`,`content`);

--
-- Indexes for table `ad_role`
--
ALTER TABLE `ad_role`
  ADD PRIMARY KEY (`kode`);

--
-- Indexes for table `ad_role_menu`
--
ALTER TABLE `ad_role_menu`
  ADD PRIMARY KEY (`kode`);

--
-- Indexes for table `ad_runteks`
--
ALTER TABLE `ad_runteks`
  ADD PRIMARY KEY (`runteksid`);

--
-- Indexes for table `ad_sitecounter`
--
ALTER TABLE `ad_sitecounter`
  ADD PRIMARY KEY (`counterid`);

--
-- Indexes for table `ad_slider`
--
ALTER TABLE `ad_slider`
  ADD PRIMARY KEY (`slider_id`);

--
-- Indexes for table `ad_type`
--
ALTER TABLE `ad_type`
  ADD PRIMARY KEY (`type_id`);

--
-- Indexes for table `ad_user`
--
ALTER TABLE `ad_user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `UNQKEY` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ad_galeri`
--
ALTER TABLE `ad_galeri`
  MODIFY `galeri_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `ad_image`
--
ALTER TABLE `ad_image`
  MODIFY `image_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `ad_kategori_artikel`
--
ALTER TABLE `ad_kategori_artikel`
  MODIFY `tbl_id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `ad_kategori_galeri`
--
ALTER TABLE `ad_kategori_galeri`
  MODIFY `cat_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ad_kategori_project`
--
ALTER TABLE `ad_kategori_project`
  MODIFY `tbl_id` int(2) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ad_konfigurasi`
--
ALTER TABLE `ad_konfigurasi`
  MODIFY `kode` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `ad_log`
--
ALTER TABLE `ad_log`
  MODIFY `logid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'The log ID';

--
-- AUTO_INCREMENT for table `ad_menu`
--
ALTER TABLE `ad_menu`
  MODIFY `menu_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `ad_menu_admin`
--
ALTER TABLE `ad_menu_admin`
  MODIFY `kode` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `ad_product`
--
ALTER TABLE `ad_product`
  MODIFY `product_id` int(6) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `ad_profil`
--
ALTER TABLE `ad_profil`
  MODIFY `kode` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ad_role`
--
ALTER TABLE `ad_role`
  MODIFY `kode` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ad_role_menu`
--
ALTER TABLE `ad_role_menu`
  MODIFY `kode` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `ad_sitecounter`
--
ALTER TABLE `ad_sitecounter`
  MODIFY `counterid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=590;

--
-- AUTO_INCREMENT for table `ad_slider`
--
ALTER TABLE `ad_slider`
  MODIFY `slider_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `ad_type`
--
ALTER TABLE `ad_type`
  MODIFY `type_id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `ad_user`
--
ALTER TABLE `ad_user`
  MODIFY `user_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
